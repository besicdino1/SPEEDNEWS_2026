<!-- page content ends here -->
</main><!-- /#main-content -->

<!-- ============================================================
     SITE FOOTER
     ============================================================ -->
<footer class="site-footer">

    <div class="container footer-grid">

        <!-- Brand column -->
        <div class="footer-brand">
            <a href="<?= BASE_URL ?>/index.php" class="logo footer-logo" aria-label="SpeedNews home">
                <span class="logo-speed">SPEED</span><span class="logo-news">NEWS</span>
            </a>
            <p class="footer-tagline">
                The world of high-performance automobiles,<br>
                told by those who live it.
            </p>

            <!-- Social media icons -->
            <div class="social-icons" aria-label="Follow us on social media">

                <!-- Facebook -->
                <a href="#" class="social-icon" aria-label="Facebook" rel="noopener noreferrer">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true">
                        <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/>
                    </svg>
                </a>

                <!-- X / Twitter -->
                <a href="#" class="social-icon" aria-label="X (Twitter)" rel="noopener noreferrer">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true">
                        <path d="M4 4l16 16M4 20 20 4" stroke-linecap="round"/>
                        <path d="M20 4 4 20M4 4l7 7 9-7M20 20l-7-7-9 7"/>
                    </svg>
                </a>

                <!-- Instagram -->
                <a href="#" class="social-icon" aria-label="Instagram" rel="noopener noreferrer">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true">
                        <rect x="2" y="2" width="20" height="20" rx="5" ry="5"/>
                        <circle cx="12" cy="12" r="4"/>
                        <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/>
                    </svg>
                </a>

                <!-- YouTube -->
                <a href="#" class="social-icon" aria-label="YouTube" rel="noopener noreferrer">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true">
                        <path d="M22.54 6.42a2.78 2.78 0 0 0-1.95-1.96C18.88 4 12 4 12 4s-6.88 0-8.59.46A2.78 2.78 0 0 0 1.46 6.42 29 29 0 0 0 1 12a29 29 0 0 0 .46 5.58 2.78 2.78 0 0 0 1.95 1.96C5.12 20 12 20 12 20s6.88 0 8.59-.46a2.78 2.78 0 0 0 1.95-1.96A29 29 0 0 0 23 12a29 29 0 0 0-.46-5.58z"/>
                        <polygon points="9.75 15.02 15.5 12 9.75 8.98 9.75 15.02" fill="currentColor" stroke="none"/>
                    </svg>
                </a>

                <!-- TikTok -->
                <a href="#" class="social-icon" aria-label="TikTok" rel="noopener noreferrer">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true">
                        <path d="M9 12a4 4 0 1 0 4 4V4a5 5 0 0 0 5 5"/>
                    </svg>
                </a>

            </div><!-- /.social-icons -->
        </div><!-- /.footer-brand -->

        <!-- Quick links -->
        <div class="footer-links">
            <h3 class="footer-heading">Quick Links</h3>
            <ul>
                <li><a href="<?= BASE_URL ?>/index.php">Home</a></li>
                <li><a href="<?= BASE_URL ?>/news.php">Latest News</a></li>
                <li><a href="<?= BASE_URL ?>/gallery.php">Gallery</a></li>
                <li><a href="<?= BASE_URL ?>/about.php">About Us</a></li>
                <li><a href="<?= BASE_URL ?>/contact.php">Contact</a></li>
            </ul>
        </div>

        <!-- Tools links -->
        <div class="footer-links">
            <h3 class="footer-heading">Tools</h3>
            <ul>
                <li><a href="<?= BASE_URL ?>/api-nhtsa.php">Car Search</a></li>
                <li><a href="<?= BASE_URL ?>/api-vin.php">VIN Decoder</a></li>
                <li><a href="<?= BASE_URL ?>/register.php">Create Account</a></li>
                <li><a href="<?= BASE_URL ?>/login.php">Sign In</a></li>
            </ul>
        </div>

        <!-- Contact snippet -->
        <div class="footer-contact">
            <h3 class="footer-heading">Contact</h3>
            <address>
                <p>SpeedNews HQ<br>
                Zagrebačka Ul. 5,<br>
                10410, Velika Gorica<br>
                Croatia</p>
                <p><a href="mailto:hello@speednews.com">hello@speednews.com</a></p>
                <p>+385 91 1235 678</p>
            </address>
        </div>

    </div><!-- /.footer-grid -->

    <!-- Bottom bar -->
    <div class="footer-bottom">
        <div class="container footer-bottom-inner">
            <p>&copy; <?= date('Y') ?> Dino Bešić / SpeedNews. All rights reserved.
            </p>
            <a href="#site-header" class="back-to-top" aria-label="Back to top">
                <!-- Up arrow SVG -->
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                     width="20" height="20" aria-hidden="true">
                    <polyline points="18 15 12 9 6 15"/>
                </svg>
            </a>
        </div>
    </div>

</footer><!-- /.site-footer -->

<!-- ============================================================
     SCRIPTS
     ============================================================ -->
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
</body>
</html>
