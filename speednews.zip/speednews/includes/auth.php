<?php
// ============================================================
//  SpeedNews — Authentication Helpers
//
//  Usage:
//    require_once __DIR__ . '/auth.php';
//
//  Admin pages call:        require_admin();
//  Login-only pages call:   require_login();
//  Public pages can call:   is_logged_in() / is_admin()
// ============================================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!defined('BASE_URL')) {
    define('BASE_URL', '/speednews');
}

// ------------------------------------------------------------
//  is_logged_in()
//  Returns true when a valid session exists.
// ------------------------------------------------------------
function is_logged_in(): bool
{
    return isset($_SESSION['user_id'], $_SESSION['role']);
}

// ------------------------------------------------------------
//  is_admin()
//  Returns true when the logged-in user holds the admin role.
// ------------------------------------------------------------
function is_admin(): bool
{
    return is_logged_in() && $_SESSION['role'] === 'admin';
}

// ------------------------------------------------------------
//  require_login()
//  Redirects to login page if the visitor is not authenticated.
//  Call at the top of any page that needs a logged-in user.
// ------------------------------------------------------------
function require_login(): void
{
    if (!is_logged_in()) {
        // Store the requested URL so we can redirect back after login
        $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
        header('Location: ' . BASE_URL . '/login.php');
        exit;
    }
}

// ------------------------------------------------------------
//  require_admin()
//  Redirects non-admins away from admin-only pages.
//  Call at the very top of every admin/* page.
// ------------------------------------------------------------
function require_admin(): void
{
    if (!is_logged_in()) {
        $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
        header('Location: ' . BASE_URL . '/login.php');
        exit;
    }

    if (!is_admin()) {
        // Logged in but not an admin — send to homepage with a message
        $_SESSION['flash_error'] = 'You do not have permission to access that page.';
        header('Location: ' . BASE_URL . '/index.php');
        exit;
    }
}

// ------------------------------------------------------------
//  flash message helpers
//  Pages call set_flash() to store a one-time message, then
//  get_flash() in the view to display and clear it.
// ------------------------------------------------------------
function set_flash(string $type, string $message): void
{
    $_SESSION['flash_' . $type] = $message;
}

function get_flash(string $type): string
{
    $key = 'flash_' . $type;
    if (isset($_SESSION[$key])) {
        $msg = $_SESSION[$key];
        unset($_SESSION[$key]);
        return $msg;
    }
    return '';
}

// ------------------------------------------------------------
//  html_flash()
//  Renders a flash message as a styled <div> if one exists,
//  or returns an empty string.  Call inside the page body.
//
//  Types: 'success' | 'error' | 'info'
// ------------------------------------------------------------
function html_flash(string $type): string
{
    $msg = get_flash($type);
    if ($msg === '') {
        return '';
    }
    $safe = htmlspecialchars($msg, ENT_QUOTES, 'UTF-8');
    return '<div class="alert alert--' . $type . '" role="alert">' . $safe . '</div>';
}

// ------------------------------------------------------------
//  current_user()
//  Returns an array with basic session data for the active user,
//  or null if nobody is logged in.
// ------------------------------------------------------------
function current_user(): ?array
{
    if (!is_logged_in()) {
        return null;
    }
    return [
        'id'        => (int) $_SESSION['user_id'],
        'firstname' => $_SESSION['firstname'] ?? '',
        'lastname'  => $_SESSION['lastname']  ?? '',
        'email'     => $_SESSION['email']     ?? '',
        'role'      => $_SESSION['role'],
    ];
}
