<?php
// ============================================================
//  SpeedNews — Shared Header
//  Include at the very top of every public-facing page.
//  Pages inside admin/ include this via ../includes/header.php
// ============================================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Site-wide base URL — adjust if you place the project in a
// different subfolder under htdocs.
if (!defined('BASE_URL')) {
    define('BASE_URL', '/speednews');
}

// Pages set $page_title before including this file.
$title = isset($page_title)
    ? htmlspecialchars($page_title) . ' | SpeedNews'
    : 'SpeedNews — Automotive News';

// Highlight the active nav link
$current = basename($_SERVER['PHP_SELF']);
function nav_class(string $file, string $current): string {
    return $file === $current ? ' class="active"' : '';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="SpeedNews — Your premier source for automotive news, supercar reviews, and the latest from the high-performance world.">
    <meta name="keywords" content="automotive news, supercars, Ferrari, Lamborghini, Porsche, car reviews, speed">
    <meta name="author" content="SpeedNews Editorial Team">
    <title><?= $title ?></title>

    <!-- Favicon -->
    <link rel="icon" type="image/svg+xml"
          href="<?= BASE_URL ?>/assets/images/favicon.svg">

    <!-- Main stylesheet -->
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>

<!-- ============================================================
     SITE HEADER & NAVIGATION
     ============================================================ -->
<header class="site-header" id="site-header">
    <div class="container header-inner">

        <!-- Logo -->
        <a href="<?= BASE_URL ?>/index.php" class="logo" aria-label="SpeedNews home">
            <span class="logo-speed">SPEED</span><span class="logo-news">NEWS</span>
        </a>

        <!-- Hamburger (mobile only) -->
        <button class="hamburger" id="hamburger"
                aria-label="Toggle navigation"
                aria-controls="main-nav"
                aria-expanded="false">
            <span></span>
            <span></span>
            <span></span>
        </button>

        <!-- Primary navigation -->
        <nav class="main-nav" id="main-nav" aria-label="Primary navigation">
            <ul>
                <li>
                    <a href="<?= BASE_URL ?>/index.php"<?= nav_class('index.php', $current) ?>>Home</a>
                </li>
                <li>
                    <a href="<?= BASE_URL ?>/news.php"<?= nav_class('news.php', $current) ?>>News</a>
                </li>
                <li>
                    <a href="<?= BASE_URL ?>/gallery.php"<?= nav_class('gallery.php', $current) ?>>Gallery</a>
                </li>
                <li>
                    <a href="<?= BASE_URL ?>/about.php"<?= nav_class('about.php', $current) ?>>About</a>
                </li>
                <li>
                    <a href="<?= BASE_URL ?>/contact.php"<?= nav_class('contact.php', $current) ?>>Contact</a>
                </li>
                <li>
                    <a href="<?= BASE_URL ?>/api-nhtsa.php"<?= nav_class('api-nhtsa.php', $current) ?>>Car Search</a>
                </li>
                <li>
                    <a href="<?= BASE_URL ?>/api-vin.php"<?= nav_class('api-vin.php', $current) ?>>VIN Decoder</a>
                </li>

                <!-- Auth links -->
                <li class="nav-separator" aria-hidden="true"></li>

                <?php if (isset($_SESSION['user_id'])): ?>

                    <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                        <li>
                            <a href="<?= BASE_URL ?>/admin/index.php"
                               class="nav-btn nav-btn--admin">Admin</a>
                        </li>
                    <?php endif; ?>

                    <li>
                        <a href="<?= BASE_URL ?>/logout.php"
                           class="nav-btn nav-btn--signout">Sign Out</a>
                    </li>

                <?php else: ?>

                    <li>
                        <a href="<?= BASE_URL ?>/register.php"<?= nav_class('register.php', $current) ?>>Register</a>
                    </li>
                    <li>
                        <a href="<?= BASE_URL ?>/login.php"
                           class="nav-btn nav-btn--login<?= $current === 'login.php' ? ' active' : '' ?>">Login</a>
                    </li>

                <?php endif; ?>
            </ul>
        </nav><!-- /.main-nav -->

    </div><!-- /.header-inner -->
</header><!-- /.site-header -->

<main id="main-content">
<!-- page content begins here -->
