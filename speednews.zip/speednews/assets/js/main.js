/* ============================================================
   SpeedNews — Main JavaScript
   Vanilla JS, no dependencies, deferred via <script> at end
   of body so the DOM is always ready.
   ============================================================ */

/* ============================================================
   1. HAMBURGER / MOBILE NAV
   ============================================================ */
(function () {
    const btn = document.getElementById('hamburger');
    const nav = document.getElementById('main-nav');
    if (!btn || !nav) return;

    btn.addEventListener('click', function () {
        const isOpen = nav.classList.toggle('open');
        btn.setAttribute('aria-expanded', String(isOpen));
        // Prevent body scroll while menu is open
        document.body.style.overflow = isOpen ? 'hidden' : '';
    });

    // Close nav when a link inside it is clicked
    nav.querySelectorAll('a').forEach(function (link) {
        link.addEventListener('click', function () {
            nav.classList.remove('open');
            btn.setAttribute('aria-expanded', 'false');
            document.body.style.overflow = '';
        });
    });

    // Close nav on Escape key
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && nav.classList.contains('open')) {
            nav.classList.remove('open');
            btn.setAttribute('aria-expanded', 'false');
            document.body.style.overflow = '';
            btn.focus();
        }
    });
}());

/* ============================================================
   2. STICKY HEADER — add shadow on scroll
   ============================================================ */
(function () {
    const header = document.getElementById('site-header');
    if (!header) return;

    function onScroll() {
        if (window.scrollY > 10) {
            header.style.boxShadow = '0 2px 20px rgba(0,0,0,.6)';
        } else {
            header.style.boxShadow = '';
        }
    }

    window.addEventListener('scroll', onScroll, { passive: true });
}());

/* ============================================================
   3. GALLERY LIGHTBOX
   ============================================================ */
(function () {
    // Build lightbox elements once, reuse for every image
    const overlay = document.createElement('div');
    overlay.className = 'lightbox';
    overlay.setAttribute('role', 'dialog');
    overlay.setAttribute('aria-modal', 'true');
    overlay.setAttribute('aria-label', 'Image viewer');

    const img = document.createElement('img');
    img.alt = '';

    const closeBtn = document.createElement('button');
    closeBtn.className = 'lightbox-close';
    closeBtn.setAttribute('aria-label', 'Close image viewer');
    closeBtn.innerHTML = '&times;';

    overlay.appendChild(closeBtn);
    overlay.appendChild(img);
    document.body.appendChild(overlay);

    function openLightbox(src, caption) {
        img.src = src;
        img.alt = caption || '';
        overlay.classList.add('open');
        document.body.style.overflow = 'hidden';
        closeBtn.focus();
    }

    function closeLightbox() {
        overlay.classList.remove('open');
        document.body.style.overflow = '';
        img.src = '';
    }

    // Wire up every gallery item
    document.querySelectorAll('.gallery-item').forEach(function (item) {
        item.setAttribute('role', 'button');
        item.setAttribute('tabindex', '0');

        function trigger() {
            const src     = item.dataset.src     || item.querySelector('img')?.src || '';
            const caption = item.dataset.caption || item.querySelector('.gallery-caption')?.textContent || '';
            openLightbox(src, caption);
        }

        item.addEventListener('click', trigger);
        item.addEventListener('keydown', function (e) {
            if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); trigger(); }
        });
    });

    closeBtn.addEventListener('click', closeLightbox);

    overlay.addEventListener('click', function (e) {
        if (e.target === overlay) closeLightbox();
    });

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && overlay.classList.contains('open')) closeLightbox();
    });
}());

/* ============================================================
   4. TAB SWITCHER  (JSON / XML tabs on api-vin.php)
   ============================================================ */
(function () {
    document.querySelectorAll('.tab-bar').forEach(function (bar) {
        const buttons = bar.querySelectorAll('.tab-btn');
        // Each .tab-bar must be followed by (or contain) .tab-panel elements.
        // We look for panels inside the nearest common ancestor.
        const container = bar.closest('.tab-container') || bar.parentElement;
        const panels    = container ? container.querySelectorAll('.tab-panel') : [];

        buttons.forEach(function (btn, idx) {
            btn.addEventListener('click', function () {
                buttons.forEach(function (b) { b.classList.remove('active'); });
                panels.forEach(function (p) { p.classList.remove('active'); });
                btn.classList.add('active');
                if (panels[idx]) panels[idx].classList.add('active');
            });
        });

        // Activate first tab by default
        if (buttons[0]) buttons[0].classList.add('active');
        if (panels[0])  panels[0].classList.add('active');
    });
}());

/* ============================================================
   5. FLASH MESSAGE AUTO-DISMISS  (3 s fade-out)
   ============================================================ */
(function () {
    document.querySelectorAll('.alert').forEach(function (alert) {
        setTimeout(function () {
            alert.style.transition = 'opacity 600ms ease';
            alert.style.opacity    = '0';
            setTimeout(function () {
                if (alert.parentNode) alert.parentNode.removeChild(alert);
            }, 650);
        }, 4000);
    });
}());

/* ============================================================
   6. CONFIRM DELETE  (admin delete links / buttons)
   ============================================================ */
(function () {
    document.querySelectorAll('[data-confirm]').forEach(function (el) {
        el.addEventListener('click', function (e) {
            const msg = el.dataset.confirm || 'Are you sure you want to delete this item?';
            if (!window.confirm(msg)) {
                e.preventDefault();
            }
        });
    });
}());

/* ============================================================
   7. NHTSA API — search form (api-nhtsa.php)
   Fetches vehicle models and safety ratings, renders results.
   ============================================================ */
(function () {
    const form    = document.getElementById('nhtsa-form');
    const results = document.getElementById('nhtsa-results');
    if (!form || !results) return;

    form.addEventListener('submit', async function (e) {
        e.preventDefault();

        const make  = document.getElementById('nhtsa-make')?.value.trim();
        const model = document.getElementById('nhtsa-model')?.value.trim();
        const year  = document.getElementById('nhtsa-year')?.value.trim();

        if (!make || !year) {
            results.innerHTML = '<div class="alert alert--error">Please enter at least Make and Year.</div>';
            return;
        }

        results.innerHTML = '<div class="text-center" style="padding:2rem"><div class="spinner"></div></div>';

        try {
            // 1 — fetch models for make + year
            const modelsUrl = `https://api.nhtsa.gov/vehicles/GetModelsForMakeYear/make/${encodeURIComponent(make)}/modelYear/${encodeURIComponent(year)}?format=json`;
            const modelsRes = await fetch(modelsUrl);
            if (!modelsRes.ok) throw new Error('Models API returned ' + modelsRes.status);
            const modelsData = await modelsRes.json();

            let html = buildModelsTable(modelsData, make, year);

            // 2 — if model is also provided, fetch safety ratings
            if (model) {
                const safetyUrl = `https://api.nhtsa.gov/SafetyRatings/modelyear/${encodeURIComponent(year)}/make/${encodeURIComponent(make)}/model/${encodeURIComponent(model)}`;
                const safetyRes = await fetch(safetyUrl);
                if (safetyRes.ok) {
                    const safetyData = await safetyRes.json();
                    html += buildSafetySection(safetyData, make, model, year);
                }
            }

            results.innerHTML = html;

        } catch (err) {
            results.innerHTML = `<div class="alert alert--error">Failed to fetch data: ${escHtml(err.message)}</div>`;
        }
    });

    function buildModelsTable(data, make, year) {
        if (!data.Results || data.Results.length === 0) {
            return `<div class="alert alert--info">No models found for <strong>${escHtml(make)}</strong> (${escHtml(year)}).</div>`;
        }

        let rows = data.Results.map(function (r) {
            return `<tr>
                <td>${escHtml(String(r.MakeId || ''))}</td>
                <td>${escHtml(r.Make_Name || r.MakeName || '')}</td>
                <td>${escHtml(r.Model_Name || r.ModelName || '')}</td>
            </tr>`;
        }).join('');

        return `
        <div class="api-results">
            <h3>Models for ${escHtml(make.toUpperCase())} — ${escHtml(year)}
                <small style="font-size:.8rem;color:var(--clr-text-muted);font-weight:400">
                    (${data.Count || data.Results.length} results)
                </small>
            </h3>
            <div class="table-wrap">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Make ID</th>
                            <th>Make</th>
                            <th>Model</th>
                        </tr>
                    </thead>
                    <tbody>${rows}</tbody>
                </table>
            </div>
        </div>`;
    }

    function buildSafetySection(data, make, model, year) {
        if (!data.Results || data.Results.length === 0) {
            return `<div class="alert alert--info" style="margin-top:1.5rem">
                No safety ratings found for ${escHtml(year)} ${escHtml(make)} ${escHtml(model)}.
            </div>`;
        }

        let rows = data.Results.map(function (r) {
            return `<tr>
                <td>${escHtml(r.VehicleDescription || '')}</td>
                <td>${stars(r.OverallRating)}</td>
                <td>${stars(r.OverallFrontCrashRating)}</td>
                <td>${stars(r.OverallSideCrashRating)}</td>
                <td>${stars(r.RolloverRating)}</td>
            </tr>`;
        }).join('');

        return `
        <div class="api-results" style="margin-top:2rem">
            <h3>Safety Ratings — ${escHtml(year)} ${escHtml(make.toUpperCase())} ${escHtml(model.toUpperCase())}</h3>
            <div class="table-wrap">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Vehicle</th>
                            <th>Overall</th>
                            <th>Front Crash</th>
                            <th>Side Crash</th>
                            <th>Rollover</th>
                        </tr>
                    </thead>
                    <tbody>${rows}</tbody>
                </table>
            </div>
        </div>`;
    }

    function stars(rating) {
        const n = parseInt(rating, 10);
        if (isNaN(n) || n <= 0) return '<span style="color:var(--clr-text-faint)">N/A</span>';
        return '<span class="rating-stars">' + '★'.repeat(n) + '☆'.repeat(Math.max(0, 5 - n)) + '</span>';
    }
}());

/* ============================================================
   8. VIN DECODER — tab wiring + fetch (api-vin.php)
   The PHP page renders the form; JS handles the fetch and
   populates results without a page reload.
   ============================================================ */
(function () {
    const form    = document.getElementById('vin-form');
    const results = document.getElementById('vin-results');
    if (!form || !results) return;

    // Key fields to surface in the summary card
    const HIGHLIGHT = [
        'Make', 'Model', 'ModelYear', 'BodyClass',
        'EngineCylinders', 'DisplacementL', 'FuelTypePrimary',
        'DriveType', 'TransmissionStyle', 'PlantCountry'
    ];

    form.addEventListener('submit', async function (e) {
        e.preventDefault();

        const vin = (document.getElementById('vin-input')?.value || '').trim().toUpperCase();
        if (vin.length !== 17) {
            results.innerHTML = '<div class="alert alert--error">A valid VIN is exactly 17 characters.</div>';
            return;
        }

        results.innerHTML = '<div class="text-center" style="padding:2rem"><div class="spinner"></div></div>';

        try {
            const [jsonRes, xmlRes] = await Promise.all([
                fetch(`https://vpic.nhtsa.dot.gov/api/vehicles/decodevin/${encodeURIComponent(vin)}?format=json`),
                fetch(`https://vpic.nhtsa.dot.gov/api/vehicles/decodevin/${encodeURIComponent(vin)}?format=xml`)
            ]);

            if (!jsonRes.ok) throw new Error('JSON API returned ' + jsonRes.status);
            if (!xmlRes.ok)  throw new Error('XML API returned '  + xmlRes.status);

            const jsonData = await jsonRes.json();
            const xmlText  = await xmlRes.text();

            results.innerHTML = buildVinOutput(vin, jsonData, jsonText(jsonData), xmlText);

            // Re-initialise tabs for newly injected markup
            initNewTabs(results);

        } catch (err) {
            results.innerHTML = `<div class="alert alert--error">Decode failed: ${escHtml(err.message)}</div>`;
        }
    });

    function buildVinOutput(vin, data, jsonStr, xmlStr) {
        const map = {};
        (data.Results || []).forEach(function (r) {
            if (r.Value && r.Value !== 'Not Applicable') {
                map[r.Variable] = r.Value;
            }
        });

        // Summary card
        let fields = HIGHLIGHT.map(function (key) {
            return map[key]
                ? `<div class="vin-field"><dt>${escHtml(key.replace(/([A-Z])/g,' $1').trim())}</dt><dd>${escHtml(map[key])}</dd></div>`
                : '';
        }).join('');

        return `
        <div class="vin-card">
            <div class="vin-card-header">
                <span style="font-size:1.5rem">🚗</span>
                <div>
                    <h3>${escHtml(map.ModelYear||'')} ${escHtml(map.Make||'')} ${escHtml(map.Model||'')}</h3>
                    <span style="font-size:.85rem;color:var(--clr-text-muted)">VIN: ${escHtml(vin)}</span>
                </div>
            </div>
            <dl class="vin-fields">${fields}</dl>
        </div>

        <div class="tab-container">
            <div class="tab-bar">
                <button class="tab-btn" type="button">JSON Response</button>
                <button class="tab-btn" type="button">XML Response</button>
            </div>
            <div class="tab-panel">
                <pre class="code-block">${escHtml(jsonStr)}</pre>
            </div>
            <div class="tab-panel">
                <pre class="code-block">${escHtml(xmlStr)}</pre>
            </div>
        </div>`;
    }

    // Pretty-print JSON
    function jsonText(data) {
        try { return JSON.stringify(data, null, 2); }
        catch (_) { return String(data); }
    }

    // Activate tabs inside a freshly injected container
    function initNewTabs(root) {
        root.querySelectorAll('.tab-bar').forEach(function (bar) {
            const btns   = bar.querySelectorAll('.tab-btn');
            const cont   = bar.closest('.tab-container') || bar.parentElement;
            const panels = cont ? cont.querySelectorAll('.tab-panel') : [];

            btns.forEach(function (btn, idx) {
                btn.addEventListener('click', function () {
                    btns.forEach(function (b) { b.classList.remove('active'); });
                    panels.forEach(function (p) { p.classList.remove('active'); });
                    btn.classList.add('active');
                    if (panels[idx]) panels[idx].classList.add('active');
                });
            });

            if (btns[0])   btns[0].classList.add('active');
            if (panels[0]) panels[0].classList.add('active');
        });
    }
}());

/* ============================================================
   9. SHARED UTILITY
   ============================================================ */
function escHtml(str) {
    return String(str)
        .replace(/&/g,  '&amp;')
        .replace(/</g,  '&lt;')
        .replace(/>/g,  '&gt;')
        .replace(/"/g,  '&quot;')
        .replace(/'/g,  '&#39;');
}
