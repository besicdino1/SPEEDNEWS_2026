-- ============================================================
--  SpeedNews — University Assignment
--  Automotive News Web Application
-- ============================================================
--  Import via phpMyAdmin: click "Import", choose this file.
--  Default admin password for both accounts: password
--  (Hashed with PHP password_hash() using PASSWORD_BCRYPT)
-- ============================================================

SET SQL_MODE   = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone  = "+00:00";
SET NAMES utf8mb4;

-- ------------------------------------------------------------
-- Create & select database
-- ------------------------------------------------------------
CREATE DATABASE IF NOT EXISTS `speednews`
    DEFAULT CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE `speednews`;

-- ============================================================
-- TABLE: users
-- ============================================================
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
    `id`         INT UNSIGNED         NOT NULL AUTO_INCREMENT,
    `firstname`  VARCHAR(100)         NOT NULL,
    `lastname`   VARCHAR(100)         NOT NULL,
    `email`      VARCHAR(150)         NOT NULL,
    `password`   VARCHAR(255)         NOT NULL,
    `country`    VARCHAR(100)         NOT NULL,
    `role`       ENUM('admin','user') NOT NULL DEFAULT 'user',
    `created_at` TIMESTAMP            NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_users_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: news
-- ============================================================
DROP TABLE IF EXISTS `news`;
CREATE TABLE `news` (
    `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id`    INT UNSIGNED NOT NULL,
    `title`      VARCHAR(255) NOT NULL,
    `body`       TEXT         NOT NULL,
    `image`      VARCHAR(255)     NULL DEFAULT NULL,
    `created_at` TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `fk_news_user_idx` (`user_id`),
    CONSTRAINT `fk_news_user`
        FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: contacts
-- ============================================================
DROP TABLE IF EXISTS `contacts`;
CREATE TABLE `contacts` (
    `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `firstname`  VARCHAR(100) NOT NULL,
    `lastname`   VARCHAR(100) NOT NULL,
    `email`      VARCHAR(150) NOT NULL,
    `country`    VARCHAR(100) NOT NULL,
    `newsletter` TINYINT(1)   NOT NULL DEFAULT 0,
    `subject`    VARCHAR(255) NOT NULL,
    `message`    TEXT         NOT NULL,
    `created_at` TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: gallery
-- ============================================================
DROP TABLE IF EXISTS `gallery`;
CREATE TABLE `gallery` (
    `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `title`      VARCHAR(255) NOT NULL,
    `image`      VARCHAR(255) NOT NULL,
    `created_at` TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- SAMPLE DATA: users  (password = 'password' for both)
-- Hash: $2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi
-- ============================================================
INSERT INTO `users` (`firstname`, `lastname`, `email`, `password`, `country`, `role`, `created_at`) VALUES
(
    'Alex', 'Turner',
    'admin@speednews.com',
    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
    'United States', 'admin', '2026-01-10 09:00:00'
),
(
    'Maria', 'Santos',
    'editor@speednews.com',
    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
    'United Kingdom', 'admin', '2026-01-12 11:30:00'
);

-- ============================================================
-- SAMPLE DATA: news  (5 articles)
-- NOTE: image filenames reference placeholder files in
--       assets/images/ — replace with real photos as needed.
-- ============================================================
INSERT INTO `news` (`user_id`, `title`, `body`, `image`, `created_at`) VALUES

(
    1,
    'Ferrari SF90 XX Stradale: The Pinnacle of Prancing Horse Engineering',
    'Ferrari has outdone itself with the SF90 XX Stradale, a limited-production hypercar that pushes the boundaries of what is possible in a road-legal vehicle. Producing a staggering 1,030 horsepower from its twin-turbocharged V8 engine paired with three electric motors, this machine represents the absolute zenith of Ferrari''s hybrid technology.\n\nThe SF90 XX Stradale is more than just a numbers game. Its aerodynamic package generates up to 860 kg of downforce at top speed, allowing the car to tackle corners with surgical precision. The active suspension system, borrowed directly from Formula 1 development, continuously adapts to road conditions thousands of times per second.\n\nPerhaps most impressively, Ferrari has managed to achieve all of this performance while maintaining the everyday usability that has always distinguished Ferrari''s road cars from pure racing machinery. The cabin, while driver-focused, is equipped with the latest digital interfaces and a surprising amount of storage space. Only 799 units are planned for production, making this one of the most coveted automobiles ever created.',
    'news1.jpg',
    '2026-05-01 10:00:00'
),

(
    1,
    'Lamborghini Revuelto: The V12 Hybrid That Rewrites Supercar History',
    'Lamborghini has officially retired the legendary Aventador and ushered in a new era with the Revuelto — the world''s first high-performance HPEV (High Performance Electrified Vehicle) to feature a naturally aspirated V12 engine. With a combined output of 1,001 horsepower, the Revuelto is not merely a successor; it is a revolution.\n\nThe heart of the Revuelto remains a 6.5-litre naturally aspirated V12, producing 825 horsepower on its own. Three electric motors — one on each front axle and one integrated with the eight-speed dual-clutch gearbox — add torque-vectoring capability that previous Lamborghinis could only dream of. The result is a 0–100 km/h sprint in just 2.5 seconds.\n\nLamborghini''s design team has penned a body that is simultaneously aggressive and aerodynamically sophisticated. The sharp creases serve a functional purpose, channelling air through carefully engineered ducts to cool the battery pack and brake system. The Revuelto signals clearly that electrification does not mean the death of passion — it is passion''s next chapter.',
    'news2.jpg',
    '2026-05-05 14:30:00'
),

(
    2,
    'Porsche 911 GT3 RS: Track Weapon Disguised as a Road Car',
    'Porsche continues its tradition of engineering excellence with the 911 GT3 RS, a car that represents four decades of motorsport knowledge distilled into a street-legal package. Powered by a 4.0-litre flat-six engine producing 525 horsepower at a screaming 9,000 rpm redline, the GT3 RS makes no compromises in its pursuit of lap records.\n\nWhat sets the new GT3 RS apart from its already formidable predecessor is the revolutionary Drag Reduction System wing. Inspired directly from Formula 1, this electronically controlled active aerodynamic element reduces drag on straights and increases downforce through high-speed corners. Total aerodynamic downforce reaches 409 kg at 285 km/h — figures more associated with Le Mans prototypes than road-registered vehicles.\n\nInside, Porsche has stripped back unnecessary weight while retaining essential creature comforts. Carbon-fibre bucket seats, a motorsport-inspired instrument cluster, and a bespoke steering wheel with paddle shifters create an environment that feels closer to a race car than a grand tourer. The optional Weissach package removes even more mass, pushing the already athletic car into a different dimension of performance entirely.',
    'news3.jpg',
    '2026-05-10 09:15:00'
),

(
    2,
    'Bugatti W16 Mistral: The Last of a Legendary Engine',
    'When Bugatti announced that the W16 Mistral would be the final car to carry their legendary quad-turbocharged 8.0-litre W16 engine, the automotive world paused to pay tribute. This open-top roadster is both a farewell and a celebration of one of the greatest powerplants ever conceived, producing 1,600 horsepower — the most ever from a Bugatti production car.\n\nThe W16 engine first appeared in the original Veyron in 2005 and has been continuously refined over two decades of development. In Mistral specification it breathes through a newly designed air intake that sits dramatically behind the driver''s head, creating an instantly recognisable silhouette that references classic Bugatti roadsters of the 1920s and 1930s.\n\nOnly 99 examples will be built, all already allocated to clients before the car was officially revealed. Each Mistral is customised through Bugatti''s Sur Mesure bespoke programme, ensuring no two are identical. With a claimed top speed exceeding 420 km/h, the Mistral will enter the record books as the fastest open-top production car ever made.',
    'news4.jpg',
    '2026-05-15 16:45:00'
),

(
    1,
    'McLaren 750S: Lighter, Faster, and More Focused Than Ever Before',
    'McLaren Automotive has refined its core supercar proposition with the 750S, a car that replaces the acclaimed 720S with sharper dynamics, a lighter body, and an even more engaging driving experience. The twin-turbocharged 4.0-litre V8 now produces 750 horsepower while the car weighs just 1,277 kg in standard configuration — an outstanding power-to-weight ratio.\n\nThe visual changes from the outgoing model are evolutionary rather than revolutionary, but every modification serves an aerodynamic or weight-saving purpose. The new dihedral doors are 40% lighter than before, the front bumper incorporates larger cooling intakes, and a revised rear diffuser improves balance at all speeds. McLaren''s engineers have also lowered the centre of gravity by 5 mm compared to the 720S, improving the already exceptional handling characteristics further.\n\nInside, the 750S benefits from a revised infotainment system and a redesigned instrument cluster. The Alcantara-wrapped steering wheel features updated controls for the Proactive Chassis Control active suspension, which can now be adjusted more finely to suit different environments. Available in both Coupé and Spider configurations, the 750S firmly establishes McLaren''s position at the very pinnacle of supercar engineering.',
    'news5.jpg',
    '2026-05-20 11:00:00'
);

-- ============================================================
-- SAMPLE DATA: gallery  (6 images, different car brands)
-- NOTE: add matching JPG files to assets/images/gallery/
-- ============================================================
INSERT INTO `gallery` (`title`, `image`, `created_at`) VALUES
('Ferrari 296 GTB — Italian Passion in Carbon Fibre',          'gallery1.jpg', '2026-02-01 10:00:00'),
('Lamborghini Huracán EVO — Born on the Track',                'gallery2.jpg', '2026-02-05 12:00:00'),
('Porsche 911 Carrera 4S — Perfection Refined Over Decades',   'gallery3.jpg', '2026-02-10 14:00:00'),
('Bugatti Chiron — 1,500 Horsepower of Pure Excess',           'gallery4.jpg', '2026-02-15 16:00:00'),
('McLaren Artura — The Hybrid Supercar Redefined',             'gallery5.jpg', '2026-02-20 09:00:00'),
('Aston Martin DB12 — The World''s First Super Tourer',        'gallery6.jpg', '2026-02-25 11:00:00');
