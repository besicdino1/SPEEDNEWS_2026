<?php
// ============================================================
//  SpeedNews — Database Configuration
//  Connects to MySQL via PDO. Included by every page that
//  needs database access.  Change the constants below if your
//  XAMPP uses a different host / port / credentials.
// ============================================================

define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'speednews');
define('DB_USER', 'root');
define('DB_PASS', '');          // XAMPP default: empty password
define('DB_CHARSET', 'utf8mb4');

// PDO options applied to every connection
$dsn     = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT
         . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
} catch (PDOException $e) {
    // In production you would log this and show a generic message.
    // For this assignment we surface the error to aid debugging.
    http_response_code(500);
    exit('<div style="font-family:monospace;color:#c00;padding:2rem;">'
        . '<strong>Database connection failed:</strong><br>'
        . htmlspecialchars($e->getMessage())
        . '<br><br>Make sure XAMPP MySQL is running and the database '
        . '<strong>' . DB_NAME . '</strong> has been imported.</div>');
}
