<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';

require_admin();

$page_title  = 'Edit Article';
$form_errors = [];

// ── Resolve article ID ────────────────────────────────────────
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id < 1) {
    set_flash('error', 'No article specified.');
    header('Location: ' . BASE_URL . '/admin/index.php');
    exit;
}

// ── Load article ──────────────────────────────────────────────
$stmt = $pdo->prepare('SELECT * FROM news WHERE id = :id LIMIT 1');
$stmt->execute([':id' => $id]);
$article = $stmt->fetch();

if (!$article) {
    set_flash('error', 'Article not found.');
    header('Location: ' . BASE_URL . '/admin/index.php');
    exit;
}

// ── Constants (same as news-add) ──────────────────────────────
const ALLOWED_MIME  = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
const ALLOWED_EXT   = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
const MAX_FILE_SIZE = 5 * 1024 * 1024;
const UPLOAD_DIR    = __DIR__ . '/../assets/uploads/';

// ── Process POST ──────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $title = trim($_POST['title'] ?? '');
    $body  = trim($_POST['body']  ?? '');

    if ($title === '')             $form_errors['title'] = 'Title is required.';
    elseif (mb_strlen($title) > 255) $form_errors['title'] = 'Title may not exceed 255 characters.';
    if ($body  === '')             $form_errors['body']  = 'Article body is required.';

    // ── Image handling ────────────────────────────────────────
    $image_name = $article['image']; // keep existing by default

    // "Remove image" checkbox
    if (isset($_POST['remove_image']) && $article['image']) {
        $old_path = UPLOAD_DIR . $article['image'];
        if (is_file($old_path)) @unlink($old_path);
        $image_name = null;
    }

    // New upload replaces (or sets) the image
    if (isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
        $file = $_FILES['image'];

        if ($file['error'] !== UPLOAD_ERR_OK) {
            $form_errors['image'] = 'Upload error (code ' . $file['error'] . '). Max size: 5 MB.';
        } elseif ($file['size'] > MAX_FILE_SIZE) {
            $form_errors['image'] = 'Image exceeds the 5 MB size limit.';
        } else {
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mime  = $finfo->file($file['tmp_name']);

            if (!in_array($mime, ALLOWED_MIME, true)) {
                $form_errors['image'] = 'Only JPG, PNG, WebP, and GIF images are accepted.';
            } else {
                $ext      = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                if (!in_array($ext, ALLOWED_EXT, true)) $ext = 'jpg';
                $new_name = uniqid('news_', true) . '.' . $ext;

                if (!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR, 0755, true);

                if (move_uploaded_file($file['tmp_name'], UPLOAD_DIR . $new_name)) {
                    // Delete old file only after new one is safely stored
                    if ($article['image'] && is_file(UPLOAD_DIR . $article['image'])) {
                        @unlink(UPLOAD_DIR . $article['image']);
                    }
                    $image_name = $new_name;
                } else {
                    $form_errors['image'] = 'Failed to save the uploaded file. Check folder permissions.';
                }
            }
        }
    }

    if (empty($form_errors)) {
        $stmt = $pdo->prepare(
            'UPDATE news SET title = :ti, body = :bo, image = :im WHERE id = :id'
        );
        $stmt->execute([
            ':ti' => $title,
            ':bo' => $body,
            ':im' => $image_name,
            ':id' => $id,
        ]);

        // Refresh article data for the form
        $stmt = $pdo->prepare('SELECT * FROM news WHERE id = :id LIMIT 1');
        $stmt->execute([':id' => $id]);
        $article = $stmt->fetch();

        set_flash('success', 'Article updated successfully.');
        header('Location: ' . BASE_URL . '/admin/news-edit.php?id=' . $id);
        exit;
    }
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="admin-layout">

    <!-- Sidebar -->
    <aside class="admin-sidebar" aria-label="Admin navigation">
        <div class="admin-sidebar-title">Admin Panel</div>
        <nav class="admin-nav">
            <a href="<?= BASE_URL ?>/admin/index.php"><span>📊</span> Dashboard</a>
            <a href="<?= BASE_URL ?>/admin/users.php"><span>👥</span> Users</a>
            <a href="<?= BASE_URL ?>/admin/news-add.php"><span>✏️</span> Add News</a>
            <a href="<?= BASE_URL ?>/admin/gallery-add.php"><span>🖼</span> Add Gallery Image</a>
            <div class="admin-sidebar-title" style="margin-top:var(--sp-6)">Public Site</div>
            <a href="<?= BASE_URL ?>/news.php"><span>📰</span> View News</a>
            <a href="<?= BASE_URL ?>/gallery.php"><span>🏎</span> View Gallery</a>
            <a href="<?= BASE_URL ?>/index.php"><span>🏠</span> Back to Site</a>
        </nav>
    </aside>

    <div class="admin-main">

        <div class="admin-header">
            <div>
                <h1>Edit Article <span style="color:var(--clr-text-muted);font-weight:400">#<?= $id ?></span></h1>
                <p style="color:var(--clr-text-muted);font-size:.9rem;margin:0">
                    Last saved: <?= date('d M Y, H:i', strtotime($article['created_at'])) ?>
                </p>
            </div>
            <div style="display:flex;gap:var(--sp-3)">
                <a href="<?= BASE_URL ?>/news-single.php?id=<?= $id ?>"
                   class="btn btn--outline btn--sm" target="_blank">
                    View Live &rarr;
                </a>
                <a href="<?= BASE_URL ?>/admin/news-delete.php?id=<?= $id ?>"
                   class="btn btn--danger btn--sm"
                   data-confirm="Permanently delete this article? This cannot be undone.">
                    Delete Article
                </a>
            </div>
        </div>

        <?= html_flash('success') ?>
        <?= html_flash('error') ?>

        <form method="POST"
              action="<?= BASE_URL ?>/admin/news-edit.php?id=<?= $id ?>"
              enctype="multipart/form-data"
              novalidate>

            <div style="display:grid;grid-template-columns:1fr 340px;gap:var(--sp-6);align-items:start">

                <!-- ── Left: main fields ─────────────────────── -->
                <div style="background:var(--clr-surface);border:1px solid var(--clr-border);border-radius:var(--radius-lg);padding:var(--sp-8)">

                    <!-- Title -->
                    <div class="form-group">
                        <label for="title">Article Title <span style="color:var(--clr-accent)">*</span></label>
                        <input type="text" id="title" name="title"
                               value="<?= htmlspecialchars($article['title']) ?>"
                               required maxlength="255">
                        <?php if (isset($form_errors['title'])): ?>
                            <span style="color:var(--clr-accent);font-size:.8rem"><?= htmlspecialchars($form_errors['title']) ?></span>
                        <?php endif; ?>
                        <span class="form-hint" id="title-count"></span>
                    </div>

                    <!-- Body -->
                    <div class="form-group" style="margin-bottom:0">
                        <label for="body">
                            Article Body <span style="color:var(--clr-accent)">*</span>
                            <span style="font-weight:400;text-transform:none;letter-spacing:0;color:var(--clr-text-faint);font-size:.8rem">
                                — separate paragraphs with a blank line
                            </span>
                        </label>
                        <textarea id="body" name="body"
                                  rows="20"
                                  required><?= htmlspecialchars($article['body']) ?></textarea>
                        <?php if (isset($form_errors['body'])): ?>
                            <span style="color:var(--clr-accent);font-size:.8rem"><?= htmlspecialchars($form_errors['body']) ?></span>
                        <?php endif; ?>
                        <span class="form-hint" id="body-count"></span>
                    </div>

                </div>

                <!-- ── Right: sidebar ───────────────────────── -->
                <div style="display:flex;flex-direction:column;gap:var(--sp-5)">

                    <!-- Update box -->
                    <div style="background:var(--clr-surface);border:1px solid var(--clr-border);border-radius:var(--radius-lg);padding:var(--sp-6)">
                        <h3 style="font-size:.9rem;margin-bottom:var(--sp-4)">Update</h3>
                        <div style="font-size:.85rem;color:var(--clr-text-muted);margin-bottom:var(--sp-5)">
                            <div style="display:flex;justify-content:space-between;margin-bottom:var(--sp-2)">
                                <span>Status</span>
                                <span style="color:var(--clr-success);font-weight:600">● Live</span>
                            </div>
                            <div style="display:flex;justify-content:space-between">
                                <span>Published</span>
                                <span style="color:var(--clr-text)">
                                    <?= date('d M Y', strtotime($article['created_at'])) ?>
                                </span>
                            </div>
                        </div>
                        <button type="submit" class="btn btn--primary btn--full">
                            Save Changes
                        </button>
                        <a href="<?= BASE_URL ?>/admin/index.php"
                           class="btn btn--outline btn--full"
                           style="margin-top:var(--sp-3)">Cancel</a>
                    </div>

                    <!-- Featured image -->
                    <div style="background:var(--clr-surface);border:1px solid var(--clr-border);border-radius:var(--radius-lg);padding:var(--sp-6)">
                        <h3 style="font-size:.9rem;margin-bottom:var(--sp-4)">Featured Image</h3>

                        <!-- Current image preview -->
                        <div id="img-preview"
                             style="width:100%;aspect-ratio:16/9;border:2px dashed var(--clr-border);border-radius:var(--radius-md);margin-bottom:var(--sp-4);overflow:hidden;background:var(--clr-surface-2);display:flex;align-items:center;justify-content:center">
                            <?php if ($article['image']): ?>
                                <img id="preview-img"
                                     src="<?= BASE_URL ?>/assets/uploads/<?= htmlspecialchars($article['image']) ?>"
                                     alt="Current image"
                                     style="width:100%;height:100%;object-fit:cover">
                            <?php else: ?>
                                <span id="preview-placeholder" style="font-size:2.5rem">🖼</span>
                            <?php endif; ?>
                        </div>

                        <?php if ($article['image']): ?>
                        <!-- Remove existing image -->
                        <div class="form-check" style="margin-bottom:var(--sp-4)">
                            <input type="checkbox" id="remove_image" name="remove_image">
                            <label for="remove_image" style="color:var(--clr-accent)">
                                Remove current image
                            </label>
                        </div>
                        <?php endif; ?>

                        <!-- Upload new -->
                        <div class="form-group" style="margin-bottom:0">
                            <label for="image">Replace / Add Image
                                <span style="font-weight:400;text-transform:none;letter-spacing:0;color:var(--clr-text-faint);font-size:.78rem">
                                    JPG, PNG, WebP · max 5 MB
                                </span>
                            </label>
                            <input type="file" id="image" name="image"
                                   accept="image/jpeg,image/png,image/webp,image/gif">
                            <?php if (isset($form_errors['image'])): ?>
                                <span style="color:var(--clr-accent);font-size:.8rem"><?= htmlspecialchars($form_errors['image']) ?></span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Article info -->
                    <div style="background:var(--clr-surface);border:1px solid var(--clr-border);border-radius:var(--radius-lg);padding:var(--sp-6);font-size:.85rem;color:var(--clr-text-muted)">
                        <h3 style="font-size:.9rem;color:var(--clr-text);margin-bottom:var(--sp-4)">Article Info</h3>
                        <div style="display:flex;flex-direction:column;gap:var(--sp-3)">
                            <div style="display:flex;justify-content:space-between">
                                <span>Article ID</span>
                                <span style="font-family:var(--font-mono);color:var(--clr-text)">#<?= $id ?></span>
                            </div>
                            <div style="display:flex;justify-content:space-between">
                                <span>Image file</span>
                                <span style="font-family:var(--font-mono);font-size:.78rem;color:var(--clr-text)">
                                    <?= $article['image'] ? htmlspecialchars($article['image']) : '—' ?>
                                </span>
                            </div>
                            <div style="display:flex;justify-content:space-between">
                                <span>Direct link</span>
                                <a href="<?= BASE_URL ?>/news-single.php?id=<?= $id ?>"
                                   target="_blank" style="font-size:.78rem">View &rarr;</a>
                            </div>
                        </div>
                    </div>

                </div>
            </div><!-- /.grid -->
        </form>

    </div><!-- /.admin-main -->
</div><!-- /.admin-layout -->

<script>
(function () {
    // Title counter
    const titleInput = document.getElementById('title');
    const titleCount = document.getElementById('title-count');
    function updateTitle() {
        const n = titleInput.value.length;
        titleCount.textContent = n + ' / 255 characters';
        titleCount.style.color = n > 230 ? 'var(--clr-accent)' : '';
    }
    titleInput.addEventListener('input', updateTitle);
    updateTitle();

    // Word counter
    const bodyTA    = document.getElementById('body');
    const bodyCount = document.getElementById('body-count');
    function updateBody() {
        const words = bodyTA.value.trim().split(/\s+/).filter(Boolean).length;
        bodyCount.textContent = words + ' word' + (words !== 1 ? 's' : '');
    }
    bodyTA.addEventListener('input', updateBody);
    updateBody();

    // Image preview on new file select
    const fileInput = document.getElementById('image');
    const preview   = document.getElementById('img-preview');
    if (fileInput && preview) {
        fileInput.addEventListener('change', function () {
            const file = fileInput.files[0];
            if (!file) return;
            const reader = new FileReader();
            reader.onload = function (e) {
                preview.innerHTML = '<img src="' + e.target.result
                    + '" style="width:100%;height:100%;object-fit:cover" alt="Preview">';
            };
            reader.readAsDataURL(file);
        });
    }

    // Remove checkbox — dim the preview
    const removeChk = document.getElementById('remove_image');
    if (removeChk && preview) {
        removeChk.addEventListener('change', function () {
            preview.style.opacity = removeChk.checked ? '0.3' : '1';
        });
    }
}());
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
