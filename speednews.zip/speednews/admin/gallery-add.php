<?php
// ============================================================
//  SpeedNews — Gallery Management
//  Handles: upload new image, delete existing image
// ============================================================
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';

require_admin();

$page_title  = 'Gallery Management';
$form_errors = [];

const GALLERY_ALLOWED_MIME  = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
const GALLERY_ALLOWED_EXT   = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
const GALLERY_MAX_SIZE      = 8 * 1024 * 1024; // 8 MB
const GALLERY_DIR           = __DIR__ . '/../assets/images/gallery/';

// ── DELETE action (?delete=ID via GET) ────────────────────────
if (isset($_GET['delete'])) {
    $del_id = (int)$_GET['delete'];
    $stmt   = $pdo->prepare('SELECT image FROM gallery WHERE id = :id LIMIT 1');
    $stmt->execute([':id' => $del_id]);
    $row = $stmt->fetch();

    if ($row) {
        $img_path = GALLERY_DIR . $row['image'];
        if (is_file($img_path)) @unlink($img_path);

        $pdo->prepare('DELETE FROM gallery WHERE id = :id')->execute([':id' => $del_id]);
        set_flash('success', 'Gallery image deleted.');
    } else {
        set_flash('error', 'Image not found.');
    }

    header('Location: ' . BASE_URL . '/admin/gallery-add.php');
    exit;
}

// ── UPLOAD action (POST) ──────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $title = trim($_POST['title'] ?? '');

    if ($title === '') {
        $form_errors['title'] = 'Caption / title is required.';
    } elseif (mb_strlen($title) > 255) {
        $form_errors['title'] = 'Caption may not exceed 255 characters.';
    }

    // File is required for a new gallery entry
    if (!isset($_FILES['image']) || $_FILES['image']['error'] === UPLOAD_ERR_NO_FILE) {
        $form_errors['image'] = 'Please select an image to upload.';
    } elseif (empty($form_errors['image'])) {
        $file = $_FILES['image'];

        if ($file['error'] !== UPLOAD_ERR_OK) {
            $form_errors['image'] = 'Upload error (code ' . $file['error'] . '). Max size: 8 MB.';
        } elseif ($file['size'] > GALLERY_MAX_SIZE) {
            $form_errors['image'] = 'Image exceeds the 8 MB size limit.';
        } else {
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mime  = $finfo->file($file['tmp_name']);

            if (!in_array($mime, GALLERY_ALLOWED_MIME, true)) {
                $form_errors['image'] = 'Only JPG, PNG, WebP, and GIF images are accepted.';
            } else {
                $ext      = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                if (!in_array($ext, GALLERY_ALLOWED_EXT, true)) $ext = 'jpg';
                $filename = uniqid('gallery_', true) . '.' . $ext;

                if (!is_dir(GALLERY_DIR)) mkdir(GALLERY_DIR, 0755, true);

                if (!move_uploaded_file($file['tmp_name'], GALLERY_DIR . $filename)) {
                    $form_errors['image'] = 'Failed to save the file. Check folder permissions on assets/images/gallery/.';
                }
            }
        }
    }

    if (empty($form_errors)) {
        $pdo->prepare('INSERT INTO gallery (title, image) VALUES (:ti, :im)')
            ->execute([':ti' => $title, ':im' => $filename]);

        set_flash('success', 'Image "' . htmlspecialchars($title) . '" added to gallery.');
        header('Location: ' . BASE_URL . '/admin/gallery-add.php');
        exit;
    }
}

// ── Load all gallery images ───────────────────────────────────
$images = $pdo->query(
    'SELECT id, title, image, created_at FROM gallery ORDER BY created_at DESC'
)->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="admin-layout">

    <!-- Sidebar -->
    <aside class="admin-sidebar" aria-label="Admin navigation">
        <div class="admin-sidebar-title">Admin Panel</div>
        <nav class="admin-nav">
            <a href="<?= BASE_URL ?>/admin/index.php"><span>📊</span> Dashboard</a>
            <a href="<?= BASE_URL ?>/admin/users.php"><span>👥</span> Users</a>
            <a href="<?= BASE_URL ?>/admin/news-add.php"><span>✏️</span> Add News</a>
            <a href="<?= BASE_URL ?>/admin/gallery-add.php" class="active"><span>🖼</span> Gallery</a>
            <div class="admin-sidebar-title" style="margin-top:var(--sp-6)">Public Site</div>
            <a href="<?= BASE_URL ?>/news.php"><span>📰</span> View News</a>
            <a href="<?= BASE_URL ?>/gallery.php"><span>🏎</span> View Gallery</a>
            <a href="<?= BASE_URL ?>/index.php"><span>🏠</span> Back to Site</a>
        </nav>
    </aside>

    <div class="admin-main">

        <div class="admin-header">
            <div>
                <h1>Gallery Management</h1>
                <p style="color:var(--clr-text-muted);font-size:.9rem;margin:0">
                    <?= count($images) ?> image<?= count($images) !== 1 ? 's' : '' ?> in the collection
                </p>
            </div>
            <a href="<?= BASE_URL ?>/gallery.php" class="btn btn--outline btn--sm" target="_blank">
                View Gallery &rarr;
            </a>
        </div>

        <?= html_flash('success') ?>
        <?= html_flash('error') ?>

        <div style="display:grid;grid-template-columns:380px 1fr;gap:var(--sp-8);align-items:start">

            <!-- ── Upload form ───────────────────────────────── -->
            <div style="background:var(--clr-surface);border:1px solid var(--clr-border);border-radius:var(--radius-lg);padding:var(--sp-8);position:sticky;top:calc(var(--header-h) + var(--sp-6))">

                <h2 style="font-size:1.1rem;margin-bottom:var(--sp-6)">Upload New Image</h2>

                <form method="POST"
                      action="<?= BASE_URL ?>/admin/gallery-add.php"
                      enctype="multipart/form-data"
                      novalidate>

                    <!-- Drop zone / preview -->
                    <div id="drop-zone"
                         style="width:100%;aspect-ratio:4/3;border:2px dashed var(--clr-border);border-radius:var(--radius-md);display:flex;flex-direction:column;align-items:center;justify-content:center;margin-bottom:var(--sp-5);overflow:hidden;background:var(--clr-surface-2);cursor:pointer;transition:border-color var(--transition)"
                         role="button" tabindex="0" aria-label="Click or drop image here">
                        <span id="drop-icon" style="font-size:2.5rem;margin-bottom:var(--sp-3)">📷</span>
                        <span id="drop-label" style="font-size:.85rem;color:var(--clr-text-muted);text-align:center;padding-inline:var(--sp-4)">
                            Click to choose or drag &amp; drop an image here
                        </span>
                    </div>

                    <!-- Hidden file input triggered by drop zone click -->
                    <input type="file" id="image" name="image"
                           accept="image/jpeg,image/png,image/webp,image/gif"
                           style="display:none">
                    <?php if (isset($form_errors['image'])): ?>
                        <div class="alert alert--error" style="margin-top:calc(var(--sp-3) * -1);margin-bottom:var(--sp-4)">
                            <?= htmlspecialchars($form_errors['image']) ?>
                        </div>
                    <?php endif; ?>

                    <!-- Caption -->
                    <div class="form-group">
                        <label for="title">
                            Caption / Title <span style="color:var(--clr-accent)">*</span>
                        </label>
                        <input type="text" id="title" name="title"
                               value="<?= htmlspecialchars($_POST['title'] ?? '') ?>"
                               placeholder="e.g. Ferrari 296 GTB — Italian Passion in Carbon Fibre"
                               required maxlength="255">
                        <?php if (isset($form_errors['title'])): ?>
                            <span style="color:var(--clr-accent);font-size:.8rem">
                                <?= htmlspecialchars($form_errors['title']) ?>
                            </span>
                        <?php endif; ?>
                        <span class="form-hint">Shown as a caption overlay on the gallery page.</span>
                    </div>

                    <div style="background:var(--clr-surface-2);border:1px solid var(--clr-border);border-radius:var(--radius-sm);padding:var(--sp-4);margin-bottom:var(--sp-5);font-size:.8rem;color:var(--clr-text-muted)">
                        <strong style="color:var(--clr-text);display:block;margin-bottom:var(--sp-2)">Guidelines</strong>
                        <ul style="list-style:disc;padding-left:var(--sp-5);line-height:1.8">
                            <li>Formats: JPG, PNG, WebP, GIF</li>
                            <li>Maximum size: 8 MB</li>
                            <li>Recommended ratio: 4:3 or 16:9</li>
                            <li>Minimum width: 800 px for best quality</li>
                        </ul>
                    </div>

                    <button type="submit" class="btn btn--primary btn--full">
                        Upload to Gallery
                    </button>

                </form>
            </div>

            <!-- ── Existing images grid ──────────────────────── -->
            <div>
                <h2 style="font-size:1rem;margin-bottom:var(--sp-5);color:var(--clr-text-muted)">
                    Current Gallery
                </h2>

                <?php if (empty($images)): ?>
                    <div class="no-results">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                            <rect x="3" y="3" width="18" height="18" rx="2"/>
                            <circle cx="8.5" cy="8.5" r="1.5"/>
                            <polyline points="21 15 16 10 5 21"/>
                        </svg>
                        <p>No images yet. Upload the first one.</p>
                    </div>
                <?php else: ?>
                    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:var(--sp-4)">
                        <?php foreach ($images as $img): ?>
                        <div style="background:var(--clr-surface);border:1px solid var(--clr-border);border-radius:var(--radius-md);overflow:hidden;transition:border-color var(--transition)"
                             onmouseover="this.style.borderColor='var(--clr-accent)'"
                             onmouseout="this.style.borderColor='var(--clr-border)'">

                            <!-- Thumbnail -->
                            <div style="aspect-ratio:4/3;overflow:hidden;background:var(--clr-surface-2)">
                                <img
                                    src="<?= BASE_URL ?>/assets/images/gallery/<?= htmlspecialchars($img['image']) ?>"
                                    alt="<?= htmlspecialchars($img['title']) ?>"
                                    style="width:100%;height:100%;object-fit:cover;transition:transform .3s"
                                    loading="lazy"
                                    onmouseover="this.style.transform='scale(1.06)'"
                                    onmouseout="this.style.transform='scale(1)'"
                                >
                            </div>

                            <div style="padding:var(--sp-4)">
                                <!-- Caption -->
                                <p style="font-size:.82rem;color:var(--clr-text);font-weight:500;
                                           margin-bottom:var(--sp-2);line-height:1.4;
                                           display:-webkit-box;-webkit-line-clamp:2;
                                           -webkit-box-orient:vertical;overflow:hidden"
                                   title="<?= htmlspecialchars($img['title']) ?>">
                                    <?= htmlspecialchars($img['title']) ?>
                                </p>

                                <!-- Meta -->
                                <div style="font-size:.75rem;color:var(--clr-text-faint);margin-bottom:var(--sp-3)">
                                    <span>#<?= $img['id'] ?></span>
                                    &middot;
                                    <span><?= date('d M Y', strtotime($img['created_at'])) ?></span>
                                </div>

                                <!-- Filename -->
                                <div style="font-size:.72rem;font-family:var(--font-mono);color:var(--clr-text-faint);
                                            white-space:nowrap;overflow:hidden;text-overflow:ellipsis;
                                            margin-bottom:var(--sp-3)"
                                     title="<?= htmlspecialchars($img['image']) ?>">
                                    <?= htmlspecialchars($img['image']) ?>
                                </div>

                                <!-- Delete -->
                                <a href="<?= BASE_URL ?>/admin/gallery-add.php?delete=<?= $img['id'] ?>"
                                   class="btn btn--danger btn--sm btn--full"
                                   data-confirm="Delete &quot;<?= htmlspecialchars($img['title']) ?>&quot;? This also removes the image file.">
                                    Delete
                                </a>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>

        </div><!-- /.grid -->
    </div><!-- /.admin-main -->
</div><!-- /.admin-layout -->

<!-- Drop zone + preview JS -->
<script>
(function () {
    const dropZone  = document.getElementById('drop-zone');
    const fileInput = document.getElementById('image');
    const dropIcon  = document.getElementById('drop-icon');
    const dropLabel = document.getElementById('drop-label');

    if (!dropZone || !fileInput) return;

    // Click on zone → open file picker
    dropZone.addEventListener('click', function () { fileInput.click(); });
    dropZone.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); fileInput.click(); }
    });

    // Drag-over visual feedback
    ['dragenter', 'dragover'].forEach(function (evt) {
        dropZone.addEventListener(evt, function (e) {
            e.preventDefault();
            dropZone.style.borderColor = 'var(--clr-accent)';
            dropZone.style.background  = 'var(--clr-accent-dim)';
        });
    });

    ['dragleave', 'drop'].forEach(function (evt) {
        dropZone.addEventListener(evt, function (e) {
            e.preventDefault();
            dropZone.style.borderColor = '';
            dropZone.style.background  = '';
        });
    });

    // Handle dropped files
    dropZone.addEventListener('drop', function (e) {
        e.preventDefault();
        const files = e.dataTransfer.files;
        if (files.length) {
            fileInput.files = files;   // assign to the real input
            showPreview(files[0]);
        }
    });

    // Handle picker selection
    fileInput.addEventListener('change', function () {
        if (fileInput.files[0]) showPreview(fileInput.files[0]);
    });

    function showPreview(file) {
        const reader = new FileReader();
        reader.onload = function (e) {
            dropZone.innerHTML = '<img src="' + e.target.result
                + '" style="width:100%;height:100%;object-fit:cover" alt="Preview">';
        };
        reader.readAsDataURL(file);

        // Auto-fill caption if it is still empty
        const titleInput = document.getElementById('title');
        if (titleInput && titleInput.value.trim() === '') {
            titleInput.value = file.name.replace(/\.[^.]+$/, '').replace(/[-_]/g, ' ');
        }
    }
}());
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
