<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';

require_admin();

$page_title  = 'Manage Users';
$me          = current_user();
$edit_user   = null;
$form_errors = [];

// ── DELETE action ─────────────────────────────────────────────
if (isset($_GET['delete'])) {
    $del_id = (int)$_GET['delete'];

    if ($del_id === $me['id']) {
        set_flash('error', 'You cannot delete your own account.');
    } else {
        $stmt = $pdo->prepare('DELETE FROM users WHERE id = :id');
        $stmt->execute([':id' => $del_id]);
        set_flash('success', 'User deleted successfully.');
    }
    header('Location: ' . BASE_URL . '/admin/users.php');
    exit;
}

// ── EDIT form — load existing user ────────────────────────────
if (isset($_GET['edit'])) {
    $edit_id = (int)$_GET['edit'];
    $stmt    = $pdo->prepare('SELECT * FROM users WHERE id = :id LIMIT 1');
    $stmt->execute([':id' => $edit_id]);
    $edit_user = $stmt->fetch();

    if (!$edit_user) {
        set_flash('error', 'User not found.');
        header('Location: ' . BASE_URL . '/admin/users.php');
        exit;
    }
}

// ── SAVE edit (POST) ──────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_id'])) {
    $uid       = (int)$_POST['user_id'];
    $firstname = trim($_POST['firstname'] ?? '');
    $lastname  = trim($_POST['lastname']  ?? '');
    $email     = trim($_POST['email']     ?? '');
    $role      = $_POST['role'] === 'admin' ? 'admin' : 'user';
    $new_pw    = $_POST['new_password'] ?? '';

    if ($firstname === '')                           $form_errors['firstname'] = 'Required.';
    if ($lastname  === '')                           $form_errors['lastname']  = 'Required.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $form_errors['email']     = 'Valid email required.';

    // Duplicate email — allow the same user to keep their email
    if (empty($form_errors['email'])) {
        $chk = $pdo->prepare('SELECT id FROM users WHERE email = :em AND id != :id LIMIT 1');
        $chk->execute([':em' => $email, ':id' => $uid]);
        if ($chk->fetch()) $form_errors['email'] = 'Email already used by another account.';
    }

    if ($new_pw !== '' && strlen($new_pw) < 8) {
        $form_errors['new_password'] = 'New password must be at least 8 characters.';
    }

    if (empty($form_errors)) {
        if ($new_pw !== '') {
            $stmt = $pdo->prepare(
                'UPDATE users SET firstname=:fn, lastname=:ln, email=:em,
                 role=:ro, password=:pw WHERE id=:id'
            );
            $stmt->execute([
                ':fn' => $firstname, ':ln' => $lastname, ':em' => $email,
                ':ro' => $role, ':pw' => password_hash($new_pw, PASSWORD_DEFAULT),
                ':id' => $uid,
            ]);
        } else {
            $stmt = $pdo->prepare(
                'UPDATE users SET firstname=:fn, lastname=:ln, email=:em,
                 role=:ro WHERE id=:id'
            );
            $stmt->execute([
                ':fn' => $firstname, ':ln' => $lastname,
                ':em' => $email, ':ro' => $role, ':id' => $uid,
            ]);
        }

        set_flash('success', 'User updated successfully.');
        header('Location: ' . BASE_URL . '/admin/users.php');
        exit;
    }

    // Reload edit_user with posted values for repopulation
    $edit_user = [
        'id'        => $uid,
        'firstname' => $firstname,
        'lastname'  => $lastname,
        'email'     => $email,
        'role'      => $role,
    ];
}

// ── Full user list ────────────────────────────────────────────
$users = $pdo->query(
    'SELECT id, firstname, lastname, email, country, role, created_at
     FROM users ORDER BY created_at DESC'
)->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="admin-layout">

    <!-- Sidebar -->
    <aside class="admin-sidebar" aria-label="Admin navigation">
        <div class="admin-sidebar-title">Admin Panel</div>
        <nav class="admin-nav">
            <a href="<?= BASE_URL ?>/admin/index.php"><span>📊</span> Dashboard</a>
            <a href="<?= BASE_URL ?>/admin/users.php" class="active"><span>👥</span> Users</a>
            <a href="<?= BASE_URL ?>/admin/news-add.php"><span>✏️</span> Add News</a>
            <a href="<?= BASE_URL ?>/admin/gallery-add.php"><span>🖼</span> Add Gallery Image</a>
            <div class="admin-sidebar-title" style="margin-top:var(--sp-6)">Public Site</div>
            <a href="<?= BASE_URL ?>/news.php"><span>📰</span> View News</a>
            <a href="<?= BASE_URL ?>/gallery.php"><span>🏎</span> View Gallery</a>
            <a href="<?= BASE_URL ?>/index.php"><span>🏠</span> Back to Site</a>
        </nav>
    </aside>

    <div class="admin-main">

        <div class="admin-header">
            <div>
                <h1>Manage Users</h1>
                <p style="color:var(--clr-text-muted);font-size:.9rem;margin:0">
                    <?= count($users) ?> registered account<?= count($users) !== 1 ? 's' : '' ?>
                </p>
            </div>
        </div>

        <?= html_flash('success') ?>
        <?= html_flash('error') ?>

        <!-- ── Edit form (shown when ?edit=ID is in URL) ─────── -->
        <?php if ($edit_user): ?>
        <div style="background:var(--clr-surface);border:1px solid var(--clr-accent);border-radius:var(--radius-lg);padding:var(--sp-8);margin-bottom:var(--sp-8)">
            <h2 style="font-size:1.1rem;margin-bottom:var(--sp-6)">
                Edit User — <span style="color:var(--clr-text-muted)">#<?= (int)$edit_user['id'] ?></span>
            </h2>

            <form method="POST" action="<?= BASE_URL ?>/admin/users.php">
                <input type="hidden" name="user_id" value="<?= (int)$edit_user['id'] ?>">

                <div class="form-grid-2">
                    <div class="form-group">
                        <label for="e-firstname">First Name</label>
                        <input type="text" id="e-firstname" name="firstname"
                               value="<?= htmlspecialchars($edit_user['firstname']) ?>"
                               required maxlength="100">
                        <?php if (isset($form_errors['firstname'])): ?>
                            <span style="color:var(--clr-accent);font-size:.8rem"><?= $form_errors['firstname'] ?></span>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label for="e-lastname">Last Name</label>
                        <input type="text" id="e-lastname" name="lastname"
                               value="<?= htmlspecialchars($edit_user['lastname']) ?>"
                               required maxlength="100">
                        <?php if (isset($form_errors['lastname'])): ?>
                            <span style="color:var(--clr-accent);font-size:.8rem"><?= $form_errors['lastname'] ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group">
                    <label for="e-email">Email Address</label>
                    <input type="email" id="e-email" name="email"
                           value="<?= htmlspecialchars($edit_user['email']) ?>"
                           required>
                    <?php if (isset($form_errors['email'])): ?>
                        <span style="color:var(--clr-accent);font-size:.8rem"><?= $form_errors['email'] ?></span>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="e-role">Role</label>
                    <select id="e-role" name="role">
                        <option value="user"  <?= $edit_user['role'] === 'user'  ? 'selected' : '' ?>>User</option>
                        <option value="admin" <?= $edit_user['role'] === 'admin' ? 'selected' : '' ?>>Admin</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="e-pw">New Password
                        <span style="font-weight:400;text-transform:none;letter-spacing:0;color:var(--clr-text-faint);font-size:.8rem">
                            — leave blank to keep current password
                        </span>
                    </label>
                    <input type="password" id="e-pw" name="new_password"
                           placeholder="Min. 8 characters"
                           autocomplete="new-password">
                    <?php if (isset($form_errors['new_password'])): ?>
                        <span style="color:var(--clr-accent);font-size:.8rem"><?= $form_errors['new_password'] ?></span>
                    <?php endif; ?>
                </div>

                <div style="display:flex;gap:var(--sp-3);margin-top:var(--sp-4)">
                    <button type="submit" class="btn btn--primary">Save Changes</button>
                    <a href="<?= BASE_URL ?>/admin/users.php" class="btn btn--outline">Cancel</a>
                </div>
            </form>
        </div>
        <?php endif; ?>

        <!-- ── Users table ───────────────────────────────────── -->
        <div class="table-wrap">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Country</th>
                        <th>Role</th>
                        <th>Joined</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($users)): ?>
                        <tr>
                            <td colspan="7" style="text-align:center;color:var(--clr-text-muted);padding:var(--sp-10)">
                                No users found.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($users as $u): ?>
                        <tr <?= (int)$u['id'] === (int)($edit_user['id'] ?? 0) ? 'style="background:var(--clr-accent-dim)"' : '' ?>>
                            <td style="color:var(--clr-text-faint);font-size:.85rem"><?= $u['id'] ?></td>
                            <td>
                                <strong style="color:var(--clr-white)">
                                    <?= htmlspecialchars($u['firstname'] . ' ' . $u['lastname']) ?>
                                </strong>
                                <?php if ((int)$u['id'] === $me['id']): ?>
                                    <span style="font-size:.7rem;color:var(--clr-accent);margin-left:var(--sp-2)">(you)</span>
                                <?php endif; ?>
                            </td>
                            <td style="font-size:.85rem;color:var(--clr-text-muted)">
                                <?= htmlspecialchars($u['email']) ?>
                            </td>
                            <td style="font-size:.85rem;color:var(--clr-text-muted)">
                                <?= htmlspecialchars($u['country']) ?>
                            </td>
                            <td>
                                <span class="badge badge--<?= $u['role'] ?>">
                                    <?= $u['role'] === 'admin' ? '● Admin' : '● User' ?>
                                </span>
                            </td>
                            <td style="font-size:.85rem;color:var(--clr-text-muted);white-space:nowrap">
                                <?= date('d M Y', strtotime($u['created_at'])) ?>
                            </td>
                            <td style="white-space:nowrap">
                                <a href="<?= BASE_URL ?>/admin/users.php?edit=<?= $u['id'] ?>"
                                   class="btn btn--ghost btn--sm">Edit</a>

                                <?php if ((int)$u['id'] !== $me['id']): ?>
                                    <a href="<?= BASE_URL ?>/admin/users.php?delete=<?= $u['id'] ?>"
                                       class="btn btn--danger btn--sm"
                                       data-confirm="Delete user <?= htmlspecialchars($u['firstname'] . ' ' . $u['lastname']) ?>? This cannot be undone.">
                                        Delete
                                    </a>
                                <?php else: ?>
                                    <button class="btn btn--danger btn--sm" disabled
                                            title="You cannot delete your own account"
                                            style="opacity:.4;cursor:not-allowed">
                                        Delete
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

    </div><!-- /.admin-main -->
</div><!-- /.admin-layout -->

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
