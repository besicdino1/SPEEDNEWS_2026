<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';

require_admin();

$page_title  = 'Add News Article';
$form_errors = [];
$old         = ['title' => '', 'body' => ''];

// ── Allowed image config ──────────────────────────────────────
const ALLOWED_MIME  = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
const ALLOWED_EXT   = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5 MB
const UPLOAD_DIR    = __DIR__ . '/../assets/uploads/';

// ── Process POST ──────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $title = trim($_POST['title'] ?? '');
    $body  = trim($_POST['body']  ?? '');

    // Validation — text fields
    if ($title === '')        $form_errors['title'] = 'Title is required.';
    elseif (mb_strlen($title) > 255) $form_errors['title'] = 'Title may not exceed 255 characters.';

    if ($body === '')         $form_errors['body']  = 'Article body is required.';

    // Validation — image upload (optional)
    $image_name = null;

    if (isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
        $file = $_FILES['image'];

        if ($file['error'] !== UPLOAD_ERR_OK) {
            $form_errors['image'] = 'Upload error (code ' . $file['error'] . '). Max size: 5 MB.';
        } elseif ($file['size'] > MAX_FILE_SIZE) {
            $form_errors['image'] = 'Image exceeds the 5 MB size limit.';
        } else {
            // Verify MIME type via finfo — do not trust $_FILES['type']
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mime  = $finfo->file($file['tmp_name']);

            if (!in_array($mime, ALLOWED_MIME, true)) {
                $form_errors['image'] = 'Only JPG, PNG, WebP, and GIF images are accepted.';
            } else {
                $ext        = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                if (!in_array($ext, ALLOWED_EXT, true)) $ext = 'jpg';
                $image_name = uniqid('news_', true) . '.' . $ext;

                if (!is_dir(UPLOAD_DIR)) {
                    mkdir(UPLOAD_DIR, 0755, true);
                }

                if (!move_uploaded_file($file['tmp_name'], UPLOAD_DIR . $image_name)) {
                    $form_errors['image'] = 'Failed to save the uploaded file. Check folder permissions.';
                    $image_name = null;
                }
            }
        }
    }

    // Insert if no errors
    if (empty($form_errors)) {
        $user = current_user();
        $stmt = $pdo->prepare(
            'INSERT INTO news (user_id, title, body, image)
             VALUES (:uid, :ti, :bo, :im)'
        );
        $stmt->execute([
            ':uid' => $user['id'],
            ':ti'  => $title,
            ':bo'  => $body,
            ':im'  => $image_name,
        ]);

        $new_id = (int)$pdo->lastInsertId();
        set_flash('success', 'Article "' . htmlspecialchars($title) . '" published successfully.');
        header('Location: ' . BASE_URL . '/admin/news-edit.php?id=' . $new_id);
        exit;
    }

    $old = [
        'title' => htmlspecialchars($title),
        'body'  => htmlspecialchars($body),
    ];
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="admin-layout">

    <!-- Sidebar -->
    <aside class="admin-sidebar" aria-label="Admin navigation">
        <div class="admin-sidebar-title">Admin Panel</div>
        <nav class="admin-nav">
            <a href="<?= BASE_URL ?>/admin/index.php"><span>📊</span> Dashboard</a>
            <a href="<?= BASE_URL ?>/admin/users.php"><span>👥</span> Users</a>
            <a href="<?= BASE_URL ?>/admin/news-add.php" class="active"><span>✏️</span> Add News</a>
            <a href="<?= BASE_URL ?>/admin/gallery-add.php"><span>🖼</span> Add Gallery Image</a>
            <div class="admin-sidebar-title" style="margin-top:var(--sp-6)">Public Site</div>
            <a href="<?= BASE_URL ?>/news.php"><span>📰</span> View News</a>
            <a href="<?= BASE_URL ?>/gallery.php"><span>🏎</span> View Gallery</a>
            <a href="<?= BASE_URL ?>/index.php"><span>🏠</span> Back to Site</a>
        </nav>
    </aside>

    <div class="admin-main">

        <div class="admin-header">
            <div>
                <h1>Add News Article</h1>
                <p style="color:var(--clr-text-muted);font-size:.9rem;margin:0">
                    Published immediately under your account.
                    Date is set automatically to now.
                </p>
            </div>
            <a href="<?= BASE_URL ?>/news.php" class="btn btn--outline btn--sm"
               target="_blank">View News Page &rarr;</a>
        </div>

        <?= html_flash('error') ?>

        <form method="POST"
              action="<?= BASE_URL ?>/admin/news-add.php"
              enctype="multipart/form-data"
              novalidate>

            <div style="display:grid;grid-template-columns:1fr 340px;gap:var(--sp-6);align-items:start">

                <!-- ── Left: main fields ─────────────────────── -->
                <div style="background:var(--clr-surface);border:1px solid var(--clr-border);border-radius:var(--radius-lg);padding:var(--sp-8)">

                    <!-- Title -->
                    <div class="form-group">
                        <label for="title">Article Title <span style="color:var(--clr-accent)">*</span></label>
                        <input type="text" id="title" name="title"
                               value="<?= $old['title'] ?>"
                               placeholder="e.g. Ferrari Unveils Its Most Powerful Hypercar"
                               required maxlength="255"
                               autofocus>
                        <?php if (isset($form_errors['title'])): ?>
                            <span style="color:var(--clr-accent);font-size:.8rem"><?= htmlspecialchars($form_errors['title']) ?></span>
                        <?php endif; ?>
                        <span class="form-hint" id="title-count">0 / 255 characters</span>
                    </div>

                    <!-- Body -->
                    <div class="form-group" style="margin-bottom:0">
                        <label for="body">
                            Article Body <span style="color:var(--clr-accent)">*</span>
                            <span style="font-weight:400;text-transform:none;letter-spacing:0;color:var(--clr-text-faint);font-size:.8rem">
                                — separate paragraphs with a blank line
                            </span>
                        </label>
                        <textarea id="body" name="body"
                                  rows="18"
                                  placeholder="Write your article here…&#10;&#10;Separate paragraphs with a blank line. They will render as &lt;p&gt; tags on the public site."
                                  required><?= $old['body'] ?></textarea>
                        <?php if (isset($form_errors['body'])): ?>
                            <span style="color:var(--clr-accent);font-size:.8rem"><?= htmlspecialchars($form_errors['body']) ?></span>
                        <?php endif; ?>
                        <span class="form-hint" id="body-count">0 words</span>
                    </div>
                </div>

                <!-- ── Right: sidebar controls ──────────────── -->
                <div style="display:flex;flex-direction:column;gap:var(--sp-5)">

                    <!-- Publish box -->
                    <div style="background:var(--clr-surface);border:1px solid var(--clr-border);border-radius:var(--radius-lg);padding:var(--sp-6)">
                        <h3 style="font-size:.9rem;margin-bottom:var(--sp-4)">Publish</h3>
                        <div style="font-size:.85rem;color:var(--clr-text-muted);margin-bottom:var(--sp-5)">
                            <div style="display:flex;justify-content:space-between;margin-bottom:var(--sp-2)">
                                <span>Status</span>
                                <span style="color:var(--clr-success);font-weight:600">● Published</span>
                            </div>
                            <div style="display:flex;justify-content:space-between">
                                <span>Date</span>
                                <span style="color:var(--clr-text)"><?= date('d M Y, H:i') ?></span>
                            </div>
                        </div>
                        <button type="submit" class="btn btn--primary btn--full">
                            Publish Article
                        </button>
                        <a href="<?= BASE_URL ?>/admin/index.php"
                           class="btn btn--outline btn--full"
                           style="margin-top:var(--sp-3)">Cancel</a>
                    </div>

                    <!-- Featured image -->
                    <div style="background:var(--clr-surface);border:1px solid var(--clr-border);border-radius:var(--radius-lg);padding:var(--sp-6)">
                        <h3 style="font-size:.9rem;margin-bottom:var(--sp-4)">Featured Image</h3>

                        <!-- Preview box -->
                        <div id="img-preview"
                             style="width:100%;aspect-ratio:16/9;border:2px dashed var(--clr-border);border-radius:var(--radius-md);display:flex;align-items:center;justify-content:center;margin-bottom:var(--sp-4);overflow:hidden;background:var(--clr-surface-2)">
                            <span style="font-size:2.5rem">🖼</span>
                        </div>

                        <div class="form-group" style="margin-bottom:0">
                            <label for="image">Upload Image
                                <span style="font-weight:400;text-transform:none;letter-spacing:0;color:var(--clr-text-faint);font-size:.78rem">
                                    JPG, PNG, WebP, GIF · max 5 MB
                                </span>
                            </label>
                            <input type="file" id="image" name="image"
                                   accept="image/jpeg,image/png,image/webp,image/gif">
                            <?php if (isset($form_errors['image'])): ?>
                                <span style="color:var(--clr-accent);font-size:.8rem"><?= htmlspecialchars($form_errors['image']) ?></span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Writing tips -->
                    <div style="background:var(--clr-surface);border:1px solid var(--clr-border);border-radius:var(--radius-lg);padding:var(--sp-6);font-size:.82rem;color:var(--clr-text-muted)">
                        <h3 style="font-size:.9rem;color:var(--clr-text);margin-bottom:var(--sp-3)">Writing Tips</h3>
                        <ul style="list-style:disc;padding-left:var(--sp-5);line-height:2">
                            <li>Open with the most important fact.</li>
                            <li>Keep paragraphs to 3–4 sentences.</li>
                            <li>Blank line = new paragraph on the live site.</li>
                            <li>Aim for 400–800 words for SEO benefit.</li>
                        </ul>
                    </div>
                </div>

            </div><!-- /.grid -->
        </form>

    </div><!-- /.admin-main -->
</div><!-- /.admin-layout -->

<script>
(function () {
    // Title character counter
    const titleInput = document.getElementById('title');
    const titleCount = document.getElementById('title-count');
    if (titleInput && titleCount) {
        function updateTitle() {
            const n = titleInput.value.length;
            titleCount.textContent = n + ' / 255 characters';
            titleCount.style.color = n > 230 ? 'var(--clr-accent)' : '';
        }
        titleInput.addEventListener('input', updateTitle);
        updateTitle();
    }

    // Body word counter
    const bodyTA   = document.getElementById('body');
    const bodyCount = document.getElementById('body-count');
    if (bodyTA && bodyCount) {
        function updateBody() {
            const words = bodyTA.value.trim().split(/\s+/).filter(Boolean).length;
            bodyCount.textContent = words + ' word' + (words !== 1 ? 's' : '');
        }
        bodyTA.addEventListener('input', updateBody);
        updateBody();
    }

    // Image preview
    const fileInput = document.getElementById('image');
    const preview   = document.getElementById('img-preview');
    if (fileInput && preview) {
        fileInput.addEventListener('change', function () {
            const file = fileInput.files[0];
            if (!file) return;
            const reader = new FileReader();
            reader.onload = function (e) {
                preview.innerHTML = '<img src="' + e.target.result
                    + '" style="width:100%;height:100%;object-fit:cover" alt="Preview">';
            };
            reader.readAsDataURL(file);
        });
    }
}());
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
