<?php
// ============================================================
//  SpeedNews — Delete News Article
//  GET  ?id=N        → show confirmation page
//  POST ?id=N        → perform deletion and redirect
// ============================================================
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';

require_admin();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id < 1) {
    set_flash('error', 'No article specified.');
    header('Location: ' . BASE_URL . '/admin/index.php');
    exit;
}

// ── Load article ──────────────────────────────────────────────
$stmt = $pdo->prepare('SELECT id, title, image FROM news WHERE id = :id LIMIT 1');
$stmt->execute([':id' => $id]);
$article = $stmt->fetch();

if (!$article) {
    set_flash('error', 'Article not found or already deleted.');
    header('Location: ' . BASE_URL . '/admin/index.php');
    exit;
}

// ── POST — perform deletion ───────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Delete the associated image file from disk first
    if ($article['image']) {
        $img_path = __DIR__ . '/../assets/uploads/' . $article['image'];
        if (is_file($img_path)) {
            @unlink($img_path);
        }
    }

    // Remove DB record (ON DELETE CASCADE keeps FK integrity)
    $del = $pdo->prepare('DELETE FROM news WHERE id = :id');
    $del->execute([':id' => $id]);

    set_flash('success', 'Article "' . htmlspecialchars($article['title']) . '" has been deleted.');
    header('Location: ' . BASE_URL . '/admin/index.php#tab1');
    exit;
}

// ── GET — show confirmation page ──────────────────────────────
$page_title = 'Delete Article';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="admin-layout">

    <!-- Sidebar -->
    <aside class="admin-sidebar" aria-label="Admin navigation">
        <div class="admin-sidebar-title">Admin Panel</div>
        <nav class="admin-nav">
            <a href="<?= BASE_URL ?>/admin/index.php"><span>📊</span> Dashboard</a>
            <a href="<?= BASE_URL ?>/admin/users.php"><span>👥</span> Users</a>
            <a href="<?= BASE_URL ?>/admin/news-add.php"><span>✏️</span> Add News</a>
            <a href="<?= BASE_URL ?>/admin/gallery-add.php"><span>🖼</span> Add Gallery Image</a>
            <div class="admin-sidebar-title" style="margin-top:var(--sp-6)">Public Site</div>
            <a href="<?= BASE_URL ?>/news.php"><span>📰</span> View News</a>
            <a href="<?= BASE_URL ?>/gallery.php"><span>🏎</span> View Gallery</a>
            <a href="<?= BASE_URL ?>/index.php"><span>🏠</span> Back to Site</a>
        </nav>
    </aside>

    <div class="admin-main">

        <div class="admin-header">
            <h1>Delete Article</h1>
        </div>

        <!-- Confirmation card -->
        <div style="max-width:580px">
            <div style="background:var(--clr-surface);border:1px solid #7f1d1d;border-radius:var(--radius-lg);overflow:hidden">

                <!-- Red danger header -->
                <div style="background:#7f1d1d;padding:var(--sp-5) var(--sp-6);display:flex;align-items:center;gap:var(--sp-4)">
                    <span style="font-size:1.5rem">⚠️</span>
                    <h2 style="font-size:1.1rem;color:#fff;margin:0">
                        Permanently Delete Article
                    </h2>
                </div>

                <div style="padding:var(--sp-8)">

                    <p style="color:var(--clr-text-muted);margin-bottom:var(--sp-6)">
                        You are about to permanently delete the following article.
                        This action <strong style="color:var(--clr-white)">cannot be undone</strong>
                        and will also remove the associated image file from the server.
                    </p>

                    <!-- Article preview -->
                    <div style="background:var(--clr-surface-2);border:1px solid var(--clr-border);border-radius:var(--radius-md);padding:var(--sp-5);margin-bottom:var(--sp-6);display:flex;gap:var(--sp-4);align-items:center">
                        <?php if ($article['image']): ?>
                            <img src="<?= BASE_URL ?>/assets/uploads/<?= htmlspecialchars($article['image']) ?>"
                                 alt=""
                                 style="width:80px;height:60px;object-fit:cover;border-radius:var(--radius-sm);flex-shrink:0">
                        <?php else: ?>
                            <div style="width:80px;height:60px;background:var(--clr-surface-3);border-radius:var(--radius-sm);display:flex;align-items:center;justify-content:center;font-size:1.5rem;flex-shrink:0">🏎</div>
                        <?php endif; ?>
                        <div style="min-width:0">
                            <div style="font-weight:700;color:var(--clr-white);margin-bottom:var(--sp-1);
                                        white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
                                <?= htmlspecialchars($article['title']) ?>
                            </div>
                            <div style="font-size:.8rem;color:var(--clr-text-faint);font-family:var(--font-mono)">
                                Article ID: #<?= $article['id'] ?>
                            </div>
                        </div>
                    </div>

                    <!-- What will be deleted checklist -->
                    <ul style="list-style:none;margin-bottom:var(--sp-8);display:flex;flex-direction:column;gap:var(--sp-2)">
                        <?php foreach ([
                            'Database record for this article',
                            $article['image'] ? 'Image file: ' . htmlspecialchars($article['image']) : null,
                        ] as $item):
                            if ($item === null) continue;
                        ?>
                        <li style="display:flex;align-items:center;gap:var(--sp-3);font-size:.9rem;color:var(--clr-text-muted)">
                            <span style="color:#f87171;font-size:1rem">✕</span>
                            <?= $item ?>
                        </li>
                        <?php endforeach; ?>
                    </ul>

                    <!-- Action buttons -->
                    <form method="POST"
                          action="<?= BASE_URL ?>/admin/news-delete.php?id=<?= $id ?>">
                        <div style="display:flex;gap:var(--sp-4)">
                            <button type="submit" class="btn btn--danger">
                                Yes, Delete Article
                            </button>
                            <a href="<?= BASE_URL ?>/admin/news-edit.php?id=<?= $id ?>"
                               class="btn btn--outline">
                                Cancel — Keep Article
                            </a>
                        </div>
                    </form>

                </div>
            </div>
        </div>

    </div><!-- /.admin-main -->
</div><!-- /.admin-layout -->

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
