<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';

require_admin();

$page_title = 'Admin Dashboard';

// ── Dashboard stats ───────────────────────────────────────────
$stats = [
    'users'    => (int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn(),
    'news'     => (int)$pdo->query('SELECT COUNT(*) FROM news')->fetchColumn(),
    'gallery'  => (int)$pdo->query('SELECT COUNT(*) FROM gallery')->fetchColumn(),
    'contacts' => (int)$pdo->query('SELECT COUNT(*) FROM contacts')->fetchColumn(),
];

// ── Recent data for dashboard tabs ────────────────────────────
$recent_users = $pdo->query(
    'SELECT id, firstname, lastname, email, role, created_at
     FROM users ORDER BY created_at DESC LIMIT 8'
)->fetchAll();

$recent_news = $pdo->query(
    'SELECT n.id, n.title, n.image, n.created_at,
            u.firstname, u.lastname
     FROM news n JOIN users u ON u.id = n.user_id
     ORDER BY n.created_at DESC LIMIT 8'
)->fetchAll();

$recent_gallery = $pdo->query(
    'SELECT id, title, image, created_at
     FROM gallery ORDER BY created_at DESC LIMIT 8'
)->fetchAll();

// ── Sample NHTSA JSON (fetched server-side for the tab) ───────
$nhtsa_sample_url = 'https://api.nhtsa.gov/vehicles/GetModelsForMakeYear/make/Ferrari/modelYear/2023?format=json';
$ctx = stream_context_create(['http' => ['method' => 'GET', 'timeout' => 6, 'ignore_errors' => true]]);
$nhtsa_raw  = @file_get_contents($nhtsa_sample_url, false, $ctx);
$nhtsa_json = ($nhtsa_raw !== false)
    ? json_encode(json_decode($nhtsa_raw, true), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)
    : '{ "error": "Could not reach NHTSA API — check internet connection." }';

// ── Sample VIN XML (fetched server-side for the tab) ──────────
$vin_sample     = '1HGBH41JXMN109186';
$vin_xml_url    = 'https://vpic.nhtsa.dot.gov/api/vehicles/decodevin/' . $vin_sample . '?format=xml';
$vin_raw        = @file_get_contents($vin_xml_url, false, $ctx);
$vin_xml_pretty = '';
if ($vin_raw !== false) {
    $dom = new DOMDocument('1.0');
    $dom->preserveWhiteSpace = false;
    $dom->formatOutput       = true;
    if (@$dom->loadXML($vin_raw)) {
        $vin_xml_pretty = $dom->saveXML();
    } else {
        $vin_xml_pretty = $vin_raw;
    }
} else {
    $vin_xml_pretty = '<!-- Could not reach NHTSA vPIC API -->';
}

$user = current_user();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="admin-layout">

    <!-- ══════════════════════════════════════════════════════
         SIDEBAR
         ══════════════════════════════════════════════════════ -->
    <aside class="admin-sidebar" aria-label="Admin navigation">
        <div class="admin-sidebar-title">Admin Panel</div>

        <nav class="admin-nav">
            <a href="<?= BASE_URL ?>/admin/index.php" class="active">
                <span>📊</span> Dashboard
            </a>
            <a href="<?= BASE_URL ?>/admin/users.php">
                <span>👥</span> Users
            </a>
            <a href="<?= BASE_URL ?>/admin/news-add.php">
                <span>✏️</span> Add News
            </a>
            <a href="<?= BASE_URL ?>/admin/gallery-add.php">
                <span>🖼</span> Add Gallery Image
            </a>

            <div class="admin-sidebar-title" style="margin-top:var(--sp-6)">Public Site</div>
            <a href="<?= BASE_URL ?>/news.php">
                <span>📰</span> View News
            </a>
            <a href="<?= BASE_URL ?>/gallery.php">
                <span>🏎</span> View Gallery
            </a>
            <a href="<?= BASE_URL ?>/index.php">
                <span>🏠</span> Back to Site
            </a>
        </nav>
    </aside>

    <!-- ══════════════════════════════════════════════════════
         MAIN CONTENT
         ══════════════════════════════════════════════════════ -->
    <div class="admin-main">

        <!-- Header bar -->
        <div class="admin-header">
            <div>
                <h1>Dashboard</h1>
                <p style="color:var(--clr-text-muted);font-size:.9rem;margin:0">
                    Welcome back, <strong style="color:var(--clr-white)"><?= htmlspecialchars($user['firstname']) ?></strong>
                    &mdash; <?= date('l, d F Y') ?>
                </p>
            </div>
            <a href="<?= BASE_URL ?>/admin/news-add.php" class="btn btn--primary btn--sm">
                + New Article
            </a>
        </div>

        <?= html_flash('success') ?>
        <?= html_flash('error') ?>

        <!-- ── Stat cards ────────────────────────────────────── -->
        <div class="stats-row">
            <div class="stat-card">
                <div class="stat-card-icon">👥</div>
                <div>
                    <div class="stat-card-value"><?= $stats['users'] ?></div>
                    <div class="stat-card-label">Users</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-card-icon">📰</div>
                <div>
                    <div class="stat-card-value"><?= $stats['news'] ?></div>
                    <div class="stat-card-label">Articles</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-card-icon">🖼</div>
                <div>
                    <div class="stat-card-value"><?= $stats['gallery'] ?></div>
                    <div class="stat-card-label">Gallery Images</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-card-icon">✉️</div>
                <div>
                    <div class="stat-card-value"><?= $stats['contacts'] ?></div>
                    <div class="stat-card-label">Messages</div>
                </div>
            </div>
        </div>

        <!-- ── Dashboard tabs ────────────────────────────────── -->
        <div class="admin-tabs tab-container">
            <div class="tab-bar" role="tablist" aria-label="Dashboard sections">
                <button class="tab-btn" type="button" role="tab"
                        aria-selected="true"  aria-controls="tab-users">Users</button>
                <button class="tab-btn" type="button" role="tab"
                        aria-selected="false" aria-controls="tab-news">News</button>
                <button class="tab-btn" type="button" role="tab"
                        aria-selected="false" aria-controls="tab-gallery">Gallery</button>
                <button class="tab-btn" type="button" role="tab"
                        aria-selected="false" aria-controls="tab-nhtsa">NHTSA JSON</button>
                <button class="tab-btn" type="button" role="tab"
                        aria-selected="false" aria-controls="tab-vin">VIN XML</button>
            </div>

            <!-- ── TAB: Users ─────────────────────────────────── -->
            <div class="tab-panel" id="tab-users" role="tabpanel">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:var(--sp-4)">
                    <h3 style="font-size:1rem">Recent Users</h3>
                    <a href="<?= BASE_URL ?>/admin/users.php" class="btn btn--ghost btn--sm">
                        Manage All &rarr;
                    </a>
                </div>
                <div class="table-wrap">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Joined</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($recent_users)): ?>
                                <tr><td colspan="6" style="text-align:center;color:var(--clr-text-muted)">No users found.</td></tr>
                            <?php else: ?>
                                <?php foreach ($recent_users as $u): ?>
                                <tr>
                                    <td style="color:var(--clr-text-faint)"><?= $u['id'] ?></td>
                                    <td><?= htmlspecialchars($u['firstname'] . ' ' . $u['lastname']) ?></td>
                                    <td style="font-size:.85rem;color:var(--clr-text-muted)"><?= htmlspecialchars($u['email']) ?></td>
                                    <td>
                                        <span class="badge badge--<?= $u['role'] ?>">
                                            <?= $u['role'] ?>
                                        </span>
                                    </td>
                                    <td style="font-size:.85rem;color:var(--clr-text-muted)">
                                        <?= date('d M Y', strtotime($u['created_at'])) ?>
                                    </td>
                                    <td>
                                        <a href="<?= BASE_URL ?>/admin/users.php?edit=<?= $u['id'] ?>"
                                           class="btn btn--ghost btn--sm">Edit</a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- ── TAB: News ──────────────────────────────────── -->
            <div class="tab-panel" id="tab-news" role="tabpanel">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:var(--sp-4)">
                    <h3 style="font-size:1rem">Recent Articles</h3>
                    <a href="<?= BASE_URL ?>/admin/news-add.php" class="btn btn--primary btn--sm">
                        + Add Article
                    </a>
                </div>
                <div class="table-wrap">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Title</th>
                                <th>Author</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($recent_news)): ?>
                                <tr><td colspan="5" style="text-align:center;color:var(--clr-text-muted)">No articles yet.</td></tr>
                            <?php else: ?>
                                <?php foreach ($recent_news as $n): ?>
                                <tr>
                                    <td style="color:var(--clr-text-faint)"><?= $n['id'] ?></td>
                                    <td>
                                        <a href="<?= BASE_URL ?>/news-single.php?id=<?= $n['id'] ?>"
                                           style="color:var(--clr-text)" target="_blank">
                                            <?= htmlspecialchars(mb_strimwidth($n['title'], 0, 55, '…')) ?>
                                        </a>
                                    </td>
                                    <td style="font-size:.85rem;color:var(--clr-text-muted)">
                                        <?= htmlspecialchars($n['firstname'] . ' ' . $n['lastname']) ?>
                                    </td>
                                    <td style="font-size:.85rem;color:var(--clr-text-muted)">
                                        <?= date('d M Y', strtotime($n['created_at'])) ?>
                                    </td>
                                    <td style="display:flex;gap:var(--sp-2)">
                                        <a href="<?= BASE_URL ?>/admin/news-edit.php?id=<?= $n['id'] ?>"
                                           class="btn btn--ghost btn--sm">Edit</a>
                                        <a href="<?= BASE_URL ?>/admin/news-delete.php?id=<?= $n['id'] ?>"
                                           class="btn btn--danger btn--sm"
                                           data-confirm="Delete this article? This cannot be undone.">
                                           Delete
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- ── TAB: Gallery ───────────────────────────────── -->
            <div class="tab-panel" id="tab-gallery" role="tabpanel">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:var(--sp-4)">
                    <h3 style="font-size:1rem">Gallery Images</h3>
                    <a href="<?= BASE_URL ?>/admin/gallery-add.php" class="btn btn--primary btn--sm">
                        + Upload Image
                    </a>
                </div>
                <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:var(--sp-4)">
                    <?php if (empty($recent_gallery)): ?>
                        <p style="color:var(--clr-text-muted);grid-column:1/-1">No images yet.</p>
                    <?php else: ?>
                        <?php foreach ($recent_gallery as $img): ?>
                        <div style="background:var(--clr-surface-2);border:1px solid var(--clr-border);border-radius:var(--radius-md);overflow:hidden">
                            <div style="aspect-ratio:4/3;overflow:hidden">
                                <img
                                    src="<?= BASE_URL ?>/assets/images/gallery/<?= htmlspecialchars($img['image']) ?>"
                                    alt="<?= htmlspecialchars($img['title']) ?>"
                                    style="width:100%;height:100%;object-fit:cover"
                                    loading="lazy"
                                >
                            </div>
                            <div style="padding:var(--sp-3)">
                                <p style="font-size:.8rem;color:var(--clr-text-muted);margin:0;
                                          white-space:nowrap;overflow:hidden;text-overflow:ellipsis"
                                   title="<?= htmlspecialchars($img['title']) ?>">
                                    <?= htmlspecialchars($img['title']) ?>
                                </p>
                                <div style="margin-top:var(--sp-2);display:flex;gap:var(--sp-2)">
                                    <a href="<?= BASE_URL ?>/admin/gallery-add.php?delete=<?= $img['id'] ?>"
                                       class="btn btn--danger btn--sm"
                                       data-confirm="Delete this image?"
                                       style="flex:1;justify-content:center">
                                        Delete
                                    </a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- ── TAB: NHTSA JSON ────────────────────────────── -->
            <div class="tab-panel" id="tab-nhtsa" role="tabpanel">
                <div style="margin-bottom:var(--sp-4)">
                    <h3 style="font-size:1rem">NHTSA API — JSON Sample</h3>
                    <p style="font-size:.85rem;color:var(--clr-text-muted);margin-bottom:var(--sp-3)">
                        Live response from
                        <code style="font-size:.78rem;background:var(--clr-surface-2);padding:2px 6px;border-radius:3px">
                            GetModelsForMakeYear / Ferrari / 2023
                        </code>
                        fetched server-side via PHP <code>file_get_contents()</code>.
                    </p>
                    <a href="<?= BASE_URL ?>/api-nhtsa.php" class="btn btn--ghost btn--sm">
                        Open Full NHTSA Page &rarr;
                    </a>
                </div>
                <pre class="code-block"><?= htmlspecialchars($nhtsa_json) ?></pre>
            </div>

            <!-- ── TAB: VIN XML ───────────────────────────────── -->
            <div class="tab-panel" id="tab-vin" role="tabpanel">
                <div style="margin-bottom:var(--sp-4)">
                    <h3 style="font-size:1rem">VIN Decoder — XML Sample</h3>
                    <p style="font-size:.85rem;color:var(--clr-text-muted);margin-bottom:var(--sp-3)">
                        Live XML response for VIN
                        <code style="font-size:.78rem;background:var(--clr-surface-2);padding:2px 6px;border-radius:3px;font-family:var(--font-mono)">
                            <?= htmlspecialchars($vin_sample) ?>
                        </code>
                        — pretty-printed via PHP <code>DOMDocument</code>.
                    </p>
                    <a href="<?= BASE_URL ?>/api-vin.php?vin=<?= urlencode($vin_sample) ?>" class="btn btn--ghost btn--sm">
                        Open Full VIN Decoder &rarr;
                    </a>
                </div>
                <pre class="code-block"><?= htmlspecialchars($vin_xml_pretty) ?></pre>
            </div>

        </div><!-- /.tab-container -->

    </div><!-- /.admin-main -->
</div><!-- /.admin-layout -->

<!-- Admin tab wiring -->
<script>
(function () {
    const bar    = document.querySelector('.admin-tabs .tab-bar');
    if (!bar) return;
    const btns   = bar.querySelectorAll('.tab-btn');
    const cont   = bar.closest('.tab-container');
    const panels = cont.querySelectorAll('.tab-panel');

    function activate(idx) {
        btns.forEach(function (b, i) {
            b.classList.toggle('active', i === idx);
            b.setAttribute('aria-selected', String(i === idx));
        });
        panels.forEach(function (p, i) {
            p.classList.toggle('active', i === idx);
        });
        // Persist active tab across navigation via hash
        history.replaceState(null, '', '#tab' + idx);
    }

    btns.forEach(function (btn, idx) {
        btn.addEventListener('click', function () { activate(idx); });
    });

    // Restore tab from URL hash on load
    const hash = parseInt(location.hash.replace('#tab', ''), 10);
    activate(isNaN(hash) ? 0 : Math.min(hash, btns.length - 1));
}());
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
